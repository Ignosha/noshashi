#!/bin/sh
# NOSHASHI Continuity: serve the checker on http://127.0.0.1:8765 next to your
# accounting database (read-only). Usage: ./start.sh /path/to/accounting.sqlite
set -e
if [ -z "$1" ] || [ ! -f "$1" ]; then
  echo "Usage: ./start.sh /path/to/accounting.sqlite (an existing SQLite file)" >&2
  exit 2
fi
# Resolve the database path before moving to this folder.
DB="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"
cd "$(dirname "$0")"
PY=python3
command -v "$PY" >/dev/null 2>&1 || PY=python
command -v "$PY" >/dev/null 2>&1 || { echo "Python 3 is required: https://www.python.org/downloads/" >&2; exit 1; }
exec "$PY" credit_source.py "$DB"
