NOSHASHI Continuity
===================

Checks that one issued-token deposit on the XRP Ledger was credited to your
customer exactly once: right destination, issuer, currency and amount, and
exactly one posted credit in your own books.

It runs on your own computer, next to your accounting database:
  - the payment is read from two public XRP Ledger Mainnet servers
    (s1.ripple.com and s2.ripple.com) and both answers must agree;
  - your credits are read from your database, read-only, by a small server
    that listens on 127.0.0.1 only and is never reachable from the network;
  - nothing is sent to NOSHASHI. No account, no key, no signing.

Requirements
------------
Python 3.8 or newer (standard library only; nothing to install) and a modern
browser. Works on macOS, Linux and Windows.

1. Give it your credits
-----------------------
Your database must be SQLite and contain a table or view named
continuity_credits with these text columns, one row per posted credit:

  tx_hash   the deposit's 64-character transaction hash
  amount    the credited amount as a decimal string, e.g. "25" or "1250.5"
  issuer    the token issuer's r-address
  currency  the currency code as you store it, e.g. "RLUSD" or "USD"

example-view.sql shows how to create that view from your own tables. Keep
duplicates: a deposit credited twice must appear twice, that is what
Continuity is there to catch. Use your authoritative, up-to-date database;
replica lag is outside what this tool can see.

2. Start it
-----------
macOS / Linux:   ./start.sh /path/to/accounting.sqlite
Windows:         start.bat C:\path\to\accounting.sqlite

Then open http://127.0.0.1:8765 in your browser.

3. Check a deposit
------------------
Paste the deposit's transaction hash, tick "Read fresh credits from the local
accounting adapter", and press "Verify with two servers". The report lists
every check as PASS, FAIL or UNKNOWN with the ledger index and hash, and
"Export evidence" saves it as a JSON file for your records or your auditor.

Issued tokens only (RLUSD, EUR, any IOU). XRP payments are refused with a
reason, never passed.

Verify this download
--------------------
The SHA-256 of noshashi-continuity.zip is published at
https://www.noshashi.app/continuity/ and the zip can be rebuilt from the
public source with: node scripts/package-continuity.mjs
Source: https://github.com/Ignosha/noshashi/tree/main/tools/continuity

Read-only. Not legal, compliance, audit or accounting advice. MIT licence
(see LICENSE). Questions: institutions@noshashi.app
