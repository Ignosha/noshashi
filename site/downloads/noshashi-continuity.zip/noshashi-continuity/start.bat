@echo off
rem NOSHASHI Continuity: serve the checker on http://127.0.0.1:8765 next to your
rem accounting database (read-only). Usage: start.bat C:\path\to\accounting.sqlite
if "%~1"=="" (
  echo Usage: start.bat C:\path\to\accounting.sqlite
  exit /b 2
)
rem Resolve the database path before moving to this folder.
set "DB=%~f1"
cd /d "%~dp0"
where py >nul 2>nul && (py -3 credit_source.py "%DB%" & exit /b)
where python >nul 2>nul && (python credit_source.py "%DB%" & exit /b)
echo Python 3 is required: https://www.python.org/downloads/
exit /b 1
