-- Continuity reads one table or view: continuity_credits(tx_hash, amount, issuer, currency).
-- Create it over your own ledger of posted credits. Adjust the table and column
-- names on the right-hand side to match your schema; keep the names on the left.
-- Amounts must be decimal text (not floats), one row per posted credit, and
-- duplicates must be kept.

CREATE VIEW IF NOT EXISTS continuity_credits AS
SELECT
  CAST(deposit_tx_hash AS TEXT) AS tx_hash,
  CAST(credited_amount AS TEXT) AS amount,
  CAST(token_issuer    AS TEXT) AS issuer,
  CAST(token_currency  AS TEXT) AS currency
FROM customer_credits
WHERE status = 'posted';

-- Check it: this should list each posted credit for one deposit.
-- SELECT * FROM continuity_credits WHERE tx_hash = '<64-character hash>';
