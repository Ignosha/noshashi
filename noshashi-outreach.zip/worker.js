/**
 * Noshashi institutional outreach engine + AI reply agent.
 *
 * One file, zero dependencies, no build step. Paste into the Cloudflare
 * dashboard Worker editor, bind the resources listed in README.md, done.
 *
 * Runs entirely inside Cloudflare's free plan:
 *   - Workers      request handling + cron
 *   - D1           institutions, threads, messages, suppressions
 *   - Workers AI   fit scoring, pitch writing, reply classification
 *   - Email Routing inbound replies (free, unmetered)
 * Outbound goes over SMTP to a mailbox you already own, so there is no
 * email vendor in the loop and nothing to upgrade. See sendMail().
 */


// ---------------------------------------------------------------------------
// 1. PRODUCT PROFILE - the only section you edit.
// ---------------------------------------------------------------------------

/**
 * Everything downstream reads from here. The pitch writer, the fit scorer and
 * the reply agent are all product-agnostic; this object is what makes them
 * speak about Noshashi rather than about nothing.
 *
 * Fields left as 'TODO' are treated as unfilled. productGaps() lists them and
 * the send queue refuses to drain while any remain - a half-written profile
 * must never reach a real institution. Everything short of sending still runs,
 * so an incomplete profile costs you nothing but the send itself.
 */
const PRODUCT = {
  name: 'NOSHASHI',
  url: 'https://www.noshashi.app',

  oneLiner:
    'Pre-trade liquidity forensics and issuer compliance risk scoring for the XRP Ledger.',

  description:
    'NOSHASHI measures what an XRPL order book will actually fill, rather than what it advertises, ' +
    'and folds issuer-level compliance risk - freeze flags, XLS-77 deep freeze, clawback authority, ' +
    'partial-payment exposure - into a single GO / HOLD / NO-GO adjudication per asset or counterparty. ' +
    'Desks and compliance teams do this today by hand across block explorers and spreadsheets, or not at all. ' +
    'It replaces that manual pass with one screen.',

  // TODO(confirm): "free demo access to qualified institutions" implies a working
  // product, so this is set to 'beta'. Correct it if the demo is a walkthrough
  // rather than the buyer touching live data - the agent keys its honesty on this.
  stage: 'beta',

  capabilities: [
    'Full-Exit Slippage: the real cost of exiting a position at size, not top-of-book',
    'Usable Bid Depth: order book depth filtered for spoofed, frozen and non-routable offers',
    'Per-issuer freeze flag reads across trust lines',
    'XLS-77 deep freeze (global freeze) detection on trust lines',
    'Clawback detection: which tokens have clawback enabled, and which account holds that authority',
    'Partial Payment detection: flags settlements where delivered value is far below the requested amount',
    'Settlement forensics tracing final delivered value against requested value',
    'FATF Recommendation 16 (Travel Rule) scoping per asset',
    'Issuer-to-domain credential grid for permissioned DeFi environments',
    'A single GO / HOLD / NO-GO adjudication per asset or counterparty',
  ],

  nonCapabilities: [
    'Does not execute, route, or custody trades - it is pre-trade and post-trade analysis only',
    'Does not perform wallet-behaviour or sanctions-list screening; it complements Chainalysis/TRM rather than replacing them',
    'Covers the XRP Ledger only - no other chains',
    'Is not legal advice or a regulatory opinion',
    // Stated plainly because a quant will ask, and a disclosed limitation is
    // credible where a discovered one is fatal. All three bias the measured gap
    // upward - in our own favour - which is the direction that needs disclosing.
    'Depth is measured against XRP pairs on the direct order book. Auto-bridging through XRP is not modelled, so figures for issued-currency-to-issued-currency pairs would understate reachable depth.',
    'Reachable depth means resting offers within 10% of an uncrossed mid. The 10% band is a chosen parameter, not a market fact, and a wider band gives a smaller gap.',
    'The exit simulation fills against resting offers only. It deliberately does not assume an AMM pool absorbs the remainder, so where a pool exists the true exit is better than the figure shown.',
  ],

  // Every claim needs something a procurement officer can check. The 913x figure
  // is the centrepiece of the whole pitch, so it carries the heaviest burden of
  // proof; see docs/EVIDENCE.md before this goes in front of a regulated buyer.
  proofPoints: [
    {
      // Retired: the 913x GateHub USD/XRP reading from 2026-08-23 was a
      // crossed-book snapshot and does not reproduce. Re-measured on the same
      // pair on 2026-09-08 it is 1.1x. Withheld claims are stripped from every
      // prompt, so the agent cannot cite it even if a recipient raises it.
      claim: 'Advertised XRPL depth overstates fillable depth by up to 913x (GateHub USD/XRP, 2026-08-23)',
      substantiated: false,
      evidence:
        'Does not reproduce. Same pair, same method, ledger 106,850,183 on 2026-09-08: 1.1x. The original ' +
        'reading caught a book that was crossed and poisoned by one stale offer at 29x the market. It was a ' +
        'transient condition, not a property of the pair. Superseded by the live sample below, which is ' +
        'stronger and survives a re-run.',
    },
    {
      claim: 'On thin XRPL books, advertised depth overstates reachable depth by orders of magnitude, driven mainly by unfunded offers',
      substantiated: true,
      evidence:
        'Measured live at ledger 106,850,183 (2026-09-08) via book_offers, 60 levels per side, comparing total ' +
        'listed bid depth against funded bid depth within 10% of an uncrossed mid. Bitstamp USD 1.0x, ' +
        'GateHub USD 1.1x, GateHub EUR 1.9x, CNY(rKiCet) 6.9x, Sologenic SOLO 2,545x with 94.7% of listed ' +
        'depth unfunded, Bitstamp BTC 4,841x with 90.3% unfunded. Median 4.4x across six pairs. Deep ' +
        'stablecoin books are close to honest; the gap lives in long-tail assets. Anyone can reproduce this ' +
        'against a public node.',
    },
    {
      claim: 'A resting offer can be unfunded - it occupies the book but cannot fill, and rippled reports this in taker_gets_funded',
      substantiated: true,
      evidence:
        'Protocol-level and independently verifiable: rippled returns taker_gets_funded when an offer owner ' +
        'cannot cover the listed amount. Measured 2026-09-08: 94.7% of Sologenic SOLO listed bid depth and ' +
        '90.3% of Bitstamp BTC listed bid depth was unfunded. Depth summed from TakerGets alone therefore ' +
        'overstates what the book can absorb.',
    },
    {
      claim: 'Partial Payment flag can deliver far less value than the payment amount states',
      substantiated: true,
      evidence:
        'XRPL protocol behaviour (tfPartialPayment): the Amount field is a maximum, and delivered_amount ' +
        'in transaction metadata is authoritative. Documented and independently verifiable on the ledger.',
    },
    {
      claim: 'Issuers hold protocol-level freeze, deep freeze (XLS-77) and clawback authority over assets they issue',
      substantiated: true,
      evidence:
        'Ledger-level flags readable by anyone. Clawback requires AllowTrustLineClawback to have been set ' +
        'before issuance, making it a permanent property of the asset. Independently verifiable on-ledger.',
    },
  ],

  pricing:
    'Desk tier: $749 per seat. Institution tier: $4,000/month for full compliance features, API access ' +
    'and multi-user. Qualified institutions currently receive free demo access while we build case studies.',

  // The agent may answer these on its own. Anything not covered escalates.
  faq: [
    {
      q: 'How is this different from XRPScan or Bithomp?',
      a: 'Those render raw ledger state. NOSHASHI interprets it: it simulates what your order would actually fill after removing frozen and non-routable offers, and it resolves issuer permissions into a trading decision. Explorers answer "what is on the ledger"; NOSHASHI answers "what happens if I trade this".',
    },
    {
      q: 'Do you replace Chainalysis or TRM?',
      a: 'No, and we would not pitch it that way. They screen wallet behaviour and sanctions exposure. We read issuer permissions - freeze, deep freeze, clawback - and actual delivered settlement value. Most desks that need one need the other too.',
    },
    {
      q: 'Which chains do you cover?',
      a: 'The XRP Ledger only. The analysis depends on XRPL-specific mechanics such as trust lines, issuer freeze flags, clawback and partial payments, which do not have direct equivalents elsewhere.',
    },
    {
      q: 'Where does the data come from?',
      a: 'Public XRP Ledger state and transaction metadata. Nothing about your positions or order flow is required for the liquidity or compliance analysis.',
    },
    {
      q: 'What does a demo involve?',
      a: 'Pick an asset or counterparty you already hold or trade. We run the full-exit slippage and issuer risk pass on it and walk you through the output. No integration and no data from your side is needed to see it.',
    },
    {
      q: 'What does it cost?',
      a: 'Desk tier is $749 per seat and the institution tier is $4,000/month. Qualified institutions get free demo access while we build case studies. Anything beyond list price is a conversation for a human on our side.',
    },
  ],

  // Sender identity is deployment config, not source - see sender() below.
  // It lives in Worker variables so the postal address and the sending mailbox
  // can change without a code edit, and so neither ends up in a git history.

  /**
   * One entry per vertical. `vertical` must match institutions.vertical in D1.
   * An institution whose vertical has no angle is skipped, not pitched generically.
   */
  angles: [
    {
      vertical: 'trading_desk',
      pain: 'You size an order off displayed depth, then discover on the fill that most of that depth was never reachable.',
      statusQuo: 'Eyeballing the book on an explorer, or a home-grown script nobody has re-validated since it was written.',
      outcome: 'Know your true exit price at size before you send the order, not after.',
      buyerTitles: ['Head of Trading', 'Head of OTC', 'Portfolio Manager', 'Quantitative Researcher', 'Head of Execution'],
      budgetLine: 'Market data and execution tooling',
    },
    {
      vertical: 'regulated_institution',
      pain: 'You hold or custody XRPL assets whose issuer can freeze or claw them back, and you cannot currently evidence that exposure to an auditor.',
      statusQuo: 'Manual issuer checks at onboarding, then no ongoing monitoring of the flags that actually matter.',
      outcome: 'A defensible, dated record of issuer permissions and settlement integrity for every asset you touch.',
      buyerTitles: ['Head of Digital Asset Custody', 'Chief Risk Officer', 'Head of Operational Risk', 'Head of Digital Assets'],
      budgetLine: 'Risk and control systems',
    },
    {
      vertical: 'token_issuer',
      pain: 'Assets you issued are held across trust lines you have never enumerated, and you cannot say who currently sits inside your freeze or clawback perimeter.',
      statusQuo: 'A point-in-time export at launch, and no live registry since.',
      outcome: 'A live registry of who holds your asset and what permissions apply to each line.',
      buyerTitles: ['Head of Tokenization', 'Head of Digital Assets', 'Treasury Lead', 'Head of Product'],
      budgetLine: 'Token operations and platform risk',
    },
    {
      vertical: 'compliance_function',
      pain: 'A counterparty with deep freeze enabled can lock assets mid-settlement, and a partial payment can settle for a fraction of its stated amount without anything looking wrong.',
      statusQuo: 'Sanctions and wallet screening that never inspects issuer permissions or delivered-versus-requested value.',
      outcome: 'Catch the freeze, clawback and partial-payment exposure your screening stack structurally cannot see.',
      buyerTitles: ['Chief Compliance Officer', 'Head of Financial Crime', 'MLRO', 'Head of AML'],
      budgetLine: 'Compliance technology',
    },
    {
      // Public companies holding XRP on the balance sheet. The buyer is a CFO
      // with an auditor asking questions, not a trader - so the pitch is
      // defensibility of the mark, never trading edge.
      vertical: 'treasury_holder',
      pain: 'Your XRP position is marked at a price the order book will not actually absorb, and your auditor is going to ask you to defend that mark.',
      statusQuo: 'Marking to a public reference price that describes advertised depth rather than anything you could exit into.',
      outcome: 'A dated, reproducible record of what the position could actually be exited for, and at what cost.',
      buyerTitles: ['Chief Financial Officer', 'Treasurer', 'Head of Corporate Development', 'Audit Committee Chair'],
      budgetLine: 'Audit, valuation and financial reporting',
    },
    {
      // Their pain is reconciliation, not trading. Lead with delivered value.
      vertical: 'payments_corridor',
      pain: 'A settlement can state one amount and deliver a fraction of it, and the break shows up in reconciliation days later rather than at the point of payment.',
      statusQuo: 'Crediting the stated payment amount, because that is the field every other rail would have meant.',
      outcome: 'Know the delivered value of every corridor settlement at the time it happens, not at month end.',
      buyerTitles: ['Head of Payment Operations', 'Head of Treasury', 'Head of Settlement', 'Chief Operating Officer'],
      budgetLine: 'Payment operations and reconciliation',
    },
  ],
};

// ---------------------------------------------------------------------------
// 2. Operating limits and guardrails.
// ---------------------------------------------------------------------------

const LIMITS = {
  // Gmail caps a free account at 500 recipients/day. Staying well under keeps
  // headroom for replies and keeps the sending pattern human-shaped.
  maxSendsPerDay: 60,
  // Per cron tick (cron runs every 15 min). Slow and personalised beats a blast.
  maxSendsPerTick: 5,
  // Never contact the same institution twice inside this window.
  reContactCooldownDays: 45,
  // Follow-ups per thread before it is closed as no-response.
  maxFollowUps: 2,
  followUpDelayDays: 6,
};

/**
 * Topics the agent must never handle alone, no matter how confident it sounds.
 * Getting one of these wrong in writing to a public institution is expensive
 * and hard to walk back, so they always route to a human.
 */
const ESCALATE_ALWAYS = [
  'pricing_negotiation',
  'contract_or_legal',
  'security_or_privacy_review',
  'data_processing_agreement',
  'procurement_or_rfp',
  'accessibility_compliance',
  'integration_commitment',
  'timeline_commitment',
  'complaint_or_hostile',
];

/** Intents the agent may answer on its own. */
const AUTO_OK = ['faq', 'scheduling', 'unsubscribe', 'out_of_office', 'wrong_person', 'not_interested'];

// ---------------------------------------------------------------------------
// 3. Small utilities.
// ---------------------------------------------------------------------------

const uid = () => crypto.randomUUID();
const filled = (v) => typeof v === 'string' && v.trim() !== '' && v.trim() !== 'TODO';
const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function json(data, status = 200) {
  return new Response(JSON.stringify(data, null, 2), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8' },
  });
}

function html(body, status = 200) {
  return new Response(body, { status, headers: { 'content-type': 'text/html; charset=utf-8' } });
}

/**
 * Sender identity, resolved from Worker variables at request time.
 *
 * FROM_EMAIL must be an address the SMTP account is allowed to send as. For
 * Gmail that means either the account itself or an address verified under
 * Settings > Accounts > "Send mail as" - Gmail rejects anything else at
 * MAIL FROM, so a typo here surfaces as an SMTP 5xx rather than a silent drop.
 */
function sender(env) {
  const fromEmail = env.FROM_EMAIL || '';
  return {
    fromName: env.FROM_NAME || '',
    fromEmail,
    replyTo: env.REPLY_TO || fromEmail,
    postalAddress: env.POSTAL_ADDRESS || '',
  };
}

/** Fields that must be real before a single message can leave the building. */
function productGaps(env = {}, p = PRODUCT) {
  const gaps = [];
  if (!filled(p.oneLiner)) gaps.push('oneLiner');
  if (!filled(p.description)) gaps.push('description');
  if (!filled(p.pricing)) gaps.push('pricing');
  if (!p.capabilities.length) gaps.push('capabilities');
  if (!p.angles.length) gaps.push('angles (no vertical has a pitch)');
  for (const [k, v] of Object.entries(sender(env))) if (!filled(v)) gaps.push(`sender.${k} (set ${k === 'fromName' ? 'FROM_NAME' : k === 'fromEmail' ? 'FROM_EMAIL' : k === 'replyTo' ? 'REPLY_TO' : 'POSTAL_ADDRESS'})`);
  for (const pp of p.proofPoints || []) {
    if (!filled(pp.evidence)) gaps.push(`proofPoint has no evidence: "${pp.claim}"`);
  }
  return gaps;
}

/**
 * Claims that exist but cannot yet be backed. These do not block sending - the
 * sequences stand without them - but they are surfaced on the dashboard so an
 * unsubstantiated claim never quietly becomes load-bearing.
 */
function withheldClaims(p = PRODUCT) {
  return (p.proofPoints || []).filter((x) => !x.substantiated).map((x) => x.claim);
}

const angleFor = (vertical) => (PRODUCT.angles || []).find((a) => a.vertical === vertical);

async function logEvent(env, threadId, kind, payload) {
  await env.DB.prepare('INSERT INTO events (id, thread_id, kind, payload) VALUES (?, ?, ?, ?)')
    .bind(uid(), threadId, kind, payload ? JSON.stringify(payload) : null)
    .run();
}

// ---------------------------------------------------------------------------
// 4. Compliance. Not optional, and cheaper to get right the first time.
// ---------------------------------------------------------------------------

/**
 * An opt-out is permanent and campaign-wide. Domain-scoped rows let one
 * district office suppress every address under that domain at once, which is
 * how institutions actually expect this to work.
 */
async function isSuppressed(env, email) {
  const addr = String(email).toLowerCase().trim();
  const domain = addr.split('@')[1] || '';
  const row = await env.DB.prepare(
    `SELECT id FROM suppressions
      WHERE (scope = 'email' AND value = ?) OR (scope = 'domain' AND value = ?)
      LIMIT 1`
  )
    .bind(addr, domain)
    .first();
  return !!row;
}

async function suppress(env, email, reason, scope = 'email') {
  const addr = String(email).toLowerCase().trim();
  const value = scope === 'domain' ? addr.split('@')[1] || addr : addr;
  await env.DB.prepare(
    `INSERT INTO suppressions (id, scope, value, reason) VALUES (?, ?, ?, ?)
     ON CONFLICT (scope, value) DO NOTHING`
  )
    .bind(uid(), scope, value, reason)
    .run();
}

/**
 * Signed so the link cannot be used to enumerate or suppress arbitrary
 * contacts by guessing ids.
 */
async function unsubToken(env, contactId) {
  // A zero-length HMAC key throws. Surfacing that as a 500 on the opt-out
  // endpoint would mean a recipient clicking unsubscribe sees an error, which
  // is the one failure this system must never produce.
  if (!env.UNSUB_SECRET || env.UNSUB_SECRET.length < 16) {
    throw new Error('UNSUB_SECRET is not configured');
  }
  const key = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(env.UNSUB_SECRET),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(contactId));
  return [...new Uint8Array(sig)].slice(0, 12).map((b) => b.toString(16).padStart(2, '0')).join('');
}

/** A one-click opt-out that works without the recipient having to write back. */
async function unsubscribeUrl(env, contactId) {
  const t = await unsubToken(env, contactId);
  return `${env.PUBLIC_BASE_URL}/unsubscribe?c=${encodeURIComponent(contactId)}&t=${t}`;
}

/** Appends the legally required footer. Every outbound message goes through this. */
function withFooter(body, unsubUrl, s) {
  return (
    `${body}\n\n` +
    `--\n` +
    `${s.fromName} - ${PRODUCT.name}\n` +
    `${PRODUCT.url}\n` +
    `${s.postalAddress}\n\n` +
    `You received this because we believe ${PRODUCT.name} is relevant to your work. ` +
    `To stop hearing from us, reply "unsubscribe" or use this link: ${unsubUrl}\n` +
    `Parts of this correspondence are drafted by an automated assistant, reviewed under human oversight.`
  );
}

// ---------------------------------------------------------------------------
// 5. Workers AI. Free allocation on the Cloudflare free plan.
// ---------------------------------------------------------------------------

/**
 * Cloudflare retires models on a schedule, and a hardcoded id turns that into a
 * full redeploy. Override with an AI_MODEL variable in Worker settings when the
 * default is retired - the catalogue is at
 * developers.cloudflare.com/workers-ai/models/
 *
 * (@cf/meta/llama-3.1-8b-instruct aliased to an infire- build retired 2026-05-30.)
 */
/**
 * Two models, because the two jobs are not alike.
 *
 * Writing a first-contact email to an institution is the one place quality is
 * the product, and an 8B model demonstrably reaches for phrases in its own
 * instructions. Scoring and triage return short structured JSON, where a small
 * fast model is fine and a large one would burn the free daily neuron
 * allowance for no gain - 126 scoring calls on a 70B is how you run out.
 *
 * Override either with a Worker variable when Cloudflare retires one.
 */
const DEFAULT_MODEL = '@cf/meta/llama-3.1-8b-instruct-fast';
const DEFAULT_WRITE_MODEL = '@cf/meta/llama-3.3-70b-instruct-fp8-fast';

const modelFor = (env, role = 'classify') =>
  role === 'write'
    ? env.AI_MODEL_WRITE || DEFAULT_WRITE_MODEL
    : env.AI_MODEL || DEFAULT_MODEL;

/**
 * Pulls the generated text out of a Workers AI response.
 *
 * Model families disagree about the shape: some return {response}, the
 * OpenAI-compatible ones return {choices:[{message:{content}}]}, and some
 * return content as an array of parts. Reading one key means a model swap
 * breaks generation with a TypeError, so every known shape is handled here.
 */
function aiText(res) {
  if (typeof res === 'string') return res;
  if (!res || typeof res !== 'object') return '';

  const parts = (v) =>
    Array.isArray(v) ? v.map((p) => (typeof p === 'string' ? p : p?.text ?? '')).join('') : null;

  const candidates = [
    res.response,
    res.result?.response,
    res.output_text,
    res.choices?.[0]?.message?.content,
    res.choices?.[0]?.text,
    res.result?.choices?.[0]?.message?.content,
    res.response?.response,
    res.response?.text,
    res.response?.content,
  ];
  for (const c of candidates) {
    if (typeof c === 'string' && c) return c;
    const joined = parts(c);
    if (joined) return joined;
  }
  return '';
}

async function ai(env, system, user, { maxTokens = 900, temperature = 0.4, role = "classify" } = {}) {
  const res = await env.AI.run(modelFor(env, role), {
    messages: [
      { role: 'system', content: system },
      { role: 'user', content: user },
    ],
    max_tokens: maxTokens,
    temperature,
  });
  const text = aiText(res);
  if (!text) {
    // Report the actual shape rather than failing opaquely - this is what makes
    // an unfamiliar model a one-line fix instead of a guessing game.
    throw new Error(
      `AI returned no text from ${modelFor(env, role)}. Keys: [${Object.keys(res || {}).join(', ')}]. ` +
      `Sample: ${JSON.stringify(res).slice(0, 300)}`
    );
  }
  return text.trim();
}

/** Models hedge with prose around JSON; take the first balanced object. */
function extractJson(text) {
  const start = text.indexOf('{');
  if (start === -1) return null;
  let depth = 0;
  let inStr = false;
  let escNext = false;
  for (let i = start; i < text.length; i++) {
    const ch = text[i];
    if (escNext) { escNext = false; continue; }
    if (ch === '\\') { escNext = true; continue; }
    if (ch === '"') { inStr = !inStr; continue; }
    if (inStr) continue;
    if (ch === '{') depth++;
    else if (ch === '}' && --depth === 0) {
      try { return JSON.parse(text.slice(start, i + 1)); } catch { return null; }
    }
  }
  return null;
}

/** Compact product brief injected into every prompt. */
function productBrief() {
  const p = PRODUCT;
  const lines = [
    `Product: ${p.name} (${p.url})`,
    `What it is: ${p.oneLiner}`,
    `Detail: ${p.description}`,
    `Maturity: ${p.stage}`,
    `Does: ${p.capabilities.join('; ') || 'unspecified'}`,
    `Does NOT do: ${p.nonCapabilities.join('; ') || 'unspecified'}`,
    `Pricing: ${p.pricing}`,
  ];
  // Only substantiated points reach the model. An unsubstantiated claim that is
  // never shown cannot be cited, which is a stronger guarantee than instructing
  // the model not to use it.
  const usable = (p.proofPoints || []).filter((x) => x.substantiated);
  if (usable.length) {
    lines.push(`Evidence you may cite: ${usable.map((x) => `${x.claim} (${x.evidence})`).join('; ')}`);
  }
  const withheld = (p.proofPoints || []).filter((x) => !x.substantiated);
  if (withheld.length) {
    lines.push(
      `Claims that are NOT yet substantiated and must never be stated, implied, or hinted at, ` +
      `even if the reader raises them first: ${withheld.map((x) => x.claim).join('; ')}. ` +
      `If asked about one, say the measurement is being re-run and a colleague will follow up.`
    );
  }
  return lines.join('\n');
}

/**
 * The honesty rules. These are repeated in every prompt because a single
 * fabricated capability or invented customer name in writing to a public
 * institution is not recoverable.
 */
const HONESTY = `
Hard rules, no exceptions:
- Never claim a capability that is not in the "Does" list.
- Never invent customers, logos, metrics, certifications, or case studies.
- Never state or imply a maturity beyond the stated one.
- If you do not know something, say so plainly and offer to follow up.
- No hype, no superlatives, no "revolutionary" or "game-changing".
- Write like a person who respects the reader's time.`.trim();

// ---------------------------------------------------------------------------
// 6. Fit scoring - "is my product actually good enough for them?"
// ---------------------------------------------------------------------------

/**
 * Scores one institution against the product and, importantly, records why it
 * would say no. A pipeline full of 90s that never close is worse than a short
 * list with honest risks attached, so fit_risks is required output.
 */
async function scoreFit(env, inst) {
  const angle = angleFor(inst.vertical);
  const system = `You evaluate whether a product genuinely fits a specific institution.
You are not a salesperson. You are the person who has to defend this pipeline to a skeptical investor.
Score honestly; a low score is a useful answer.
${HONESTY}

Return ONLY a JSON object:
{"score": 0-100, "reason": "<=45 words on why this institution specifically", "risks": "<=45 words on what would make them say no", "disqualified": true|false}`;

  const PRIORITY_MEANING = {
    1: '1 - reachable NOW: short decision chain, no vendor security review, can buy at beta stage',
    2: '2 - reachable AFTER 2-3 named references exist',
    3: '3 - NOT reachable at beta stage: requires SOC 2, insurance, financials, formal procurement',
    0: '0 - NOT a buyer: partner, competitor, distribution channel, or no budget for this at any price',
  };
  const priority = inst.priority === null || inst.priority === undefined ? null : Number(inst.priority);

  const user = `${productBrief()}

Institution:
- Name: ${inst.name}
- Type: ${inst.vertical}${inst.segment ? ` / ${inst.segment}` : ''}
- Location: ${[inst.region, inst.country].filter(Boolean).join(', ')}
- Scale: ${inst.size_metric || 'unknown'}
- Reachability: ${priority === null ? 'not assessed' : PRIORITY_MEANING[priority] || String(priority)}
- Analyst notes: ${inst.notes || 'none'}

${angle ? `Known pain for this vertical: ${angle.pain}\nWhat they do today: ${angle.statusQuo}` : 'No pitch angle is defined for this vertical yet.'}

You are scoring "is it worth emailing them THIS MONTH", not "would they benefit in
principle". A perfect fit that cannot transact for a year is a bad use of a
first introduction, and this pipeline exists to spend a small number of
introductions well.

Reachability is a hard constraint, not a tiebreaker:
- priority 0: score below 20 and set disqualified true, whatever the fit. Not a buyer.
- priority 3: cap at 55 however good the fit. They cannot clear vendor due
  diligence against a beta-stage product this year. Say that in the risks.
- priority 2: cap at 75. Real, but it needs references that do not exist yet.
- priority 1: score on merit, up to 100.

Within those caps:
90+ demonstrable problem, can buy this year, and the buyer is reachable
70-89 real fit with budget, timing or procurement friction
40-69 plausible but needs discovery first
<40 poor fit - say so plainly

The analyst notes above already contain a human judgement about this
institution. Where they contradict the surface impression of the name, trust the
notes. A famous institution is not a better prospect for being famous.`;

  const out = await ai(env, system, user, { maxTokens: 400, temperature: 0.2 });
  const parsed = extractJson(out) || {};
  const score = Math.max(0, Math.min(100, Number(parsed.score) || 0));

  await env.DB.prepare(
    `UPDATE institutions
        SET fit_score = ?, fit_reason = ?, fit_risks = ?,
            status = CASE WHEN ? = 1 THEN 'lost' ELSE 'researched' END,
            updated_at = datetime('now')
      WHERE id = ?`
  )
    .bind(score, parsed.reason || null, parsed.risks || null, parsed.disqualified || score < 40 ? 1 : 0, inst.id)
    .run();

  return { id: inst.id, name: inst.name, score, reason: parsed.reason, risks: parsed.risks };
}

// ---------------------------------------------------------------------------
// 7. Pitch writing.
// ---------------------------------------------------------------------------

/**
 * Deterministic checks on a generated pitch.
 *
 * Shared by /api/audit and by queuePitch, because advice a human has to
 * remember to run is not a control. Anything in CRITICAL blocks queueing
 * outright - those are the failures that put a false statement in front of an
 * institution, and no amount of prompt wording has reliably prevented them.
 */
const PITCH_CRITICAL = ['FIGURE NOT IN EVIDENCE', 'CONTAINS WITHHELD CLAIM', 'asks the recipient to send their own data'];

function pitchProblems(subject, body) {
  const problems = [];
  const lower = body.toLowerCase();
  const words = body.trim().split(/\s+/).length;
  const firstSentence = (body.split(/(?<=[.!?])\s/)[0] || '').toLowerCase();

  const LAZY_OPENERS = [
    'i hope this', 'i am reaching out', "i'm reaching out", 'i wanted to reach out',
    'hope you are well', 'quick question', 'just checking in',
    'i wanted to introduce', 'allow me to introduce',
    'as investor relations', 'as the ', 'as head of', 'as chief',
    "you're likely aware", 'you are likely aware', 'as you know',
    'you may have noticed', 'you may be aware', 'as you may know',
  ];
  const HYPE = ['revolutionary', 'game-chang', 'cutting-edge', 'world-class', 'best-in-class',
    'seamless', 'synergy', 'unparalleled', 'leverage our', 'unlock the power',
    'demonstrate our capabilities', 'showcase our'];
  const UNBACKED = ['soc 2', 'soc2', 'iso 27001', 'certified', 'trusted by', 'our customers',
    'case study', 'clients include', 'used by'];

  if (/\b913\b/.test(body)) problems.push('CONTAINS WITHHELD CLAIM');
  for (const p of LAZY_OPENERS) if (firstSentence.includes(p)) problems.push(`opens with "${p}"`);
  for (const h of HYPE) if (lower.includes(h)) problems.push(`hype: "${h}"`);
  for (const u of UNBACKED) if (lower.includes(u)) problems.push(`unbacked claim: "${u}"`);
  if (!/\b(beta|early|small team|new)\b/.test(lower)) problems.push('never admits maturity');
  if (words < 70 || words > 170) problems.push(`length ${words} words (want 90-130)`);
  if (subject.split(/\s+/).length > 8) problems.push('subject over 8 words');
  if (subject.includes(':')) problems.push('subject contains a colon');
  if (/\b(support|solutions?|services?|platform|overview|introduction|opportunity)\b/i.test(subject)) {
    problems.push(`subject reads as a service category: "${subject}"`);
  }
  if (new RegExp(`\\b${PRODUCT.name}\\b`, 'i').test(subject)) problems.push('product name in subject');

  const firstTwo = body.split(/(?<=[.!?])\s/).slice(0, 2).join(' ').toLowerCase();
  if (firstTwo.includes(PRODUCT.name.toLowerCase())) problems.push('names the product in the first two sentences');

  if (/\b(share|send|provide|forward|supply)\b[^.]{0,80}\b(snapshot|position|holdings?|balance|export|data|portfolio)\b/i.test(body)) {
    problems.push('asks the recipient to send their own data');
  }

  const allowed = ((PRODUCT.proofPoints || [])
    .filter((p) => p.substantiated)
    .map((p) => `${p.claim} ${p.evidence}`)
    .join(' ') + ' ' + PRODUCT.pricing)
    .replace(/[\s,]/g, '').toLowerCase().replace(/×/g, 'x');
  for (const f of body.match(/\d[\d,.]*\s*(?:x|×|%|bps)/gi) || []) {
    const bare = f.replace(/[\s,]/g, '').toLowerCase().replace('×', 'x');
    if (!allowed.includes(bare)) problems.push(`FIGURE NOT IN EVIDENCE: "${f.trim()}"`);
  }
  if (/\b(roughly|about|around|nearly|approximately)\s+(half|a third|a quarter|most|much)\b/i.test(body)) {
    problems.push('vague quantifier used in place of a measured figure');
  }
  return problems;
}

const criticalProblems = (problems) =>
  problems.filter((p) => PITCH_CRITICAL.some((c) => p.startsWith(c)));

/**
 * Writes the opening email for one institution. Deliberately short: the goal of
 * a first touch into an institution is a reply, not a decision.
 */
async function writePitch(env, inst, contact) {
  const angle = angleFor(inst.vertical);
  if (!angle) throw new Error(`No pitch angle defined for vertical "${inst.vertical}" - add one to PRODUCT.angles`);

  const system = `You write first-contact emails to senior staff at public institutions.
They are busy, skeptical, and have seen a hundred vendor emails this month.
${HONESTY}

THE FIRST SENTENCE DECIDES EVERYTHING. It must assert a specific fact about
their position or their market. It must NOT tell the reader what they already
know, what they are "likely aware of", or what their own job is.

Banned openings, without exception:
- "As [role] at [company]..."  - they know where they work
- "You're likely aware..." / "As you know..." / "You may have noticed..."
  - these assert nothing and read as filler
- "I'm reaching out" / "I hope this finds you" / "I wanted to introduce"
- Any first sentence that would be equally true of ten other companies

A good first sentence names a mechanism or a condition that is true of THIS
reader, in their own vocabulary. Describe the shape you are aiming for, then
write it yourself from the material below - do not copy any phrasing you have
been shown, here or anywhere in these instructions. Illustrations in this prompt
demonstrate STRUCTURE ONLY. Every fact and every figure in your email must come
from the evidence section of the material you were given. If you find yourself
reusing a sentence from these instructions, you are fabricating.

Form:
- Subject: 3-7 words naming the TENSION the reader carries, not the service you
  sell. It must not be a noun phrase of service-category words, and must not
  contain: support, solution, services, platform, overview, introduction,
  opportunity, or the product name. No colons, no questions, no "quick".
- Body: 90-130 words, plain text, no markdown, no bullet lists.
- Do NOT name the product before the third sentence. Sentences one and two
  belong to the reader's problem.
- Exactly one concrete claim, drawn only from the evidence you were given, with
  its figure. Never gesture vaguely at "challenges" or "issues".
- Say plainly that you are early. Institutions respect it and discover it anyway.
- Close with an ask smaller than a meeting. The analysis runs on PUBLIC ledger
  data, so NEVER ask them to send a position, a holding, a snapshot, an export,
  or any data of their own. Asking for data you do not need is both a large ask
  and a false one. Ask them to NAME an asset, issuer or counterparty they care
  about, and offer to run the read and send back the output. Never "book a demo".
- Match the reader's frame. A finance or investor-relations reader cares about
  defending a mark to an auditor, not about trading edge - do not use execution
  or trading vocabulary with them.
- No signature or footer; those are appended for you.

Return ONLY JSON: {"subject": "...", "body": "..."}`;

  const user = `${productBrief()}

Writing to: ${contact.name || 'a senior staff member'}, ${contact.title || 'title unknown'}
At: ${inst.name} (${inst.vertical}${inst.segment ? ` / ${inst.segment}` : ''}), ${[inst.region, inst.country].filter(Boolean).join(', ')}
Scale: ${inst.size_metric || 'unknown'}
Why we think they fit: ${inst.fit_reason || 'not yet analysed'}
Their likely objection: ${inst.fit_risks || 'unknown'}

Vertical angle:
- Pain: ${angle.pain}
- What they do today: ${angle.statusQuo}
- Outcome that matters to them: ${angle.outcome}
${angle.budgetLine ? `- Likely budget line: ${angle.budgetLine}` : ''}

WHO THIS READER IS NOT: ${inst.name} is a ${inst.segment || inst.vertical}. Do not
describe them as doing something their business does not do. A company that holds
an asset does not "quote pairs" or "run a book"; a custodian does not trade; an
issuer is not an exchange. If you are unsure what they do, write about the asset
and the ledger rather than about their operations.

FIGURES: the only numbers you may state are those in the evidence above, quoted
exactly as written there. Do not round them, average them, soften them into
"roughly half" or "a large share", or invent a new one. If no figure fits the
point you want to make, make the point without a number.`;

  const out = await ai(env, system, user, { maxTokens: 600, temperature: 0.6, role: "write" });
  const parsed = extractJson(out);
  if (!parsed?.subject || !parsed?.body) throw new Error('Pitch generation returned no usable subject/body');
  return { subject: String(parsed.subject).trim(), body: String(parsed.body).trim() };
}

/**
 * Queues the opening message. Nothing is sent here - the cron drains the queue,
 * which keeps sending paced and gives you a window to inspect what is pending.
 */
async function queuePitch(env, institutionId) {
  const inst = await env.DB.prepare('SELECT * FROM institutions WHERE id = ?').bind(institutionId).first();
  // Echo what was received: a whitespace-mangled id is invisible otherwise.
  if (!inst) throw new Error(`Institution not found for id ${JSON.stringify(institutionId)}`);

  const contact = await env.DB.prepare(
    'SELECT * FROM contacts WHERE institution_id = ? ORDER BY is_primary DESC LIMIT 1'
  )
    .bind(institutionId)
    .first();
  if (!contact) throw new Error(`No contact on record for ${inst.name}`);

  if (await isSuppressed(env, contact.email)) {
    await env.DB.prepare("UPDATE institutions SET status = 'suppressed' WHERE id = ?").bind(institutionId).run();
    return { skipped: 'suppressed' };
  }

  const recent = await env.DB.prepare(
    `SELECT m.id FROM messages m
       JOIN threads t ON t.id = m.thread_id
      WHERE t.institution_id = ? AND m.direction = 'outbound'
        AND m.created_at > datetime('now', ?)
      LIMIT 1`
  )
    .bind(institutionId, `-${LIMITS.reContactCooldownDays} days`)
    .first();
  if (recent) return { skipped: 'cooldown' };

  // Generate, check, and retry once. A pitch that fabricates a figure or asks
  // for the reader's data must never reach the queue, regardless of how the
  // prompt is worded - this is the enforcement, the prompt is only guidance.
  let subject, body, problems;
  for (let attempt = 1; attempt <= 2; attempt++) {
    ({ subject, body } = await writePitch(env, inst, contact));
    problems = pitchProblems(subject, body);
    if (!criticalProblems(problems).length) break;
    await logEvent(env, null, 'pitch_rejected', {
      institution: inst.name,
      attempt,
      problems: criticalProblems(problems),
    }).catch(() => {});
  }
  const blocking = criticalProblems(problems);
  if (blocking.length) {
    return { skipped: 'failed checks', institution: inst.name, problems: blocking, subject, body };
  }

  const threadId = uid();
  await env.DB.prepare(
    `INSERT INTO threads (id, institution_id, contact_id, subject, state, owner)
     VALUES (?, ?, ?, ?, 'open', 'agent')`
  )
    .bind(threadId, institutionId, contact.id, subject)
    .run();

  await env.DB.prepare(
    `INSERT INTO messages (id, thread_id, direction, from_addr, to_addr, subject, body, status, authored_by, send_after)
     VALUES (?, ?, 'outbound', ?, ?, ?, ?, 'queued', 'agent', datetime('now'))`
  )
    .bind(uid(), threadId, sender(env).fromEmail, contact.email, subject, body)
    .run();

  await env.DB.prepare("UPDATE institutions SET status = 'queued', updated_at = datetime('now') WHERE id = ?")
    .bind(institutionId)
    .run();
  await logEvent(env, threadId, 'pitch_queued', { institution: inst.name, subject });

  return { threadId, subject, body, to: contact.email };
}

// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// 8. Outbound mail via Resend.
// ---------------------------------------------------------------------------
//
// noshashi.app runs on Vercel DNS, so Cloudflare Email Routing is unavailable
// and the SMTP-through-Gmail path is unnecessary: the domain already has
// working SPF and DKIM for Resend, which means authenticated sending from
// institutions@noshashi.app works today with no DNS migration and no risk to
// the live site.
//
// Free forever: 3,000 emails/month, 100/day, no card. The engine paces at 60/day.
// Set RESEND_API_KEY as a Worker secret.

const RESEND_ENDPOINT = 'https://api.resend.com/emails';

/**
 * Sends one message. Returns the id Resend assigns, which is stored as the
 * message_id so a reply can be traced back to what it answers.
 */
async function sendMail(env, msg) {
  if (!env.RESEND_API_KEY) throw new Error('RESEND_API_KEY is not configured');

  const headers = {};
  if (msg.listUnsub) {
    headers['List-Unsubscribe'] = `<${msg.listUnsub}>`;
    headers['List-Unsubscribe-Post'] = 'List-Unsubscribe=One-Click';
  }
  if (msg.inReplyTo) {
    // References is what actually threads in most mail clients; send both.
    headers['In-Reply-To'] = `<${msg.inReplyTo}>`;
    headers['References'] = `<${msg.inReplyTo}>`;
  }

  const payload = {
    from: msg.fromName ? `${msg.fromName} <${msg.from}>` : msg.from,
    to: [msg.to],
    subject: msg.subject,
    text: msg.body,
  };
  if (msg.replyTo) payload.reply_to = msg.replyTo;
  if (Object.keys(headers).length) payload.headers = headers;

  const res = await fetch(RESEND_ENDPOINT, {
    method: 'POST',
    headers: {
      authorization: `Bearer ${env.RESEND_API_KEY}`,
      'content-type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  const text = await res.text();
  if (!res.ok) {
    // Surface Resend's own message - it names the cause precisely (unverified
    // domain, invalid from address, rate limit) and guessing wastes a day.
    throw new Error(`Resend ${res.status}: ${text.slice(0, 300)}`);
  }
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { /* id is optional */ }
  return parsed?.id || null;
}
// ---------------------------------------------------------------------------
// 9. The send queue. Cron drains it; nothing is sent synchronously.
// ---------------------------------------------------------------------------

async function sentToday(env) {
  const row = await env.DB.prepare(
    `SELECT COUNT(*) AS n FROM messages
      WHERE direction = 'outbound' AND status = 'sent' AND sent_at > datetime('now', '-1 day')`
  ).first();
  return row?.n || 0;
}

async function drainQueue(env) {
  // The single most important guard in the system: an unfinished product
  // profile means the AI has been given nothing true to say, so nothing leaves.
  const gaps = productGaps(env);
  if (gaps.length) return { sent: 0, blocked: `product profile incomplete: ${gaps.join(', ')}` };

  const budget = Math.min(LIMITS.maxSendsPerTick, LIMITS.maxSendsPerDay - (await sentToday(env)));
  if (budget <= 0) return { sent: 0, blocked: 'daily send limit reached' };

  const s = sender(env);

  const { results } = await env.DB.prepare(
    `SELECT m.*, t.institution_id, t.contact_id
       FROM messages m JOIN threads t ON t.id = m.thread_id
      WHERE m.direction = 'outbound' AND m.status = 'queued'
        AND (m.send_after IS NULL OR m.send_after <= datetime('now'))
      ORDER BY m.created_at LIMIT ?`
  )
    .bind(budget)
    .all();

  let sent = 0;
  const failures = [];

  for (const m of results || []) {
    // Re-checked at send time, not just at queue time: an opt-out may have
    // arrived in the window between the two.
    if (await isSuppressed(env, m.to_addr)) {
      await env.DB.prepare("UPDATE messages SET status = 'failed', status_detail = 'suppressed' WHERE id = ?")
        .bind(m.id)
        .run();
      continue;
    }

    const unsub = await unsubscribeUrl(env, m.contact_id);

    try {
      // Resend assigns the id; we record whatever it returns so a reply can be
      // traced back, and fall back to matching on the contact's address.
      const messageId = await sendMail(env, {
        from: s.fromEmail,
        fromName: s.fromName,
        replyTo: s.replyTo,
        to: m.to_addr,
        subject: m.subject,
        body: withFooter(m.body, unsub, s),
        inReplyTo: m.in_reply_to,
        listUnsub: unsub,
      });

      await env.DB.prepare(
        `UPDATE messages SET status = 'sent', message_id = ?, sent_at = datetime('now') WHERE id = ?`
      ).bind(messageId, m.id).run();
      await env.DB.prepare(
        `UPDATE threads SET state = 'awaiting_reply', last_activity = datetime('now') WHERE id = ?`
      ).bind(m.thread_id).run();
      await env.DB.prepare(
        `UPDATE institutions SET status = 'contacted', updated_at = datetime('now')
          WHERE id = ? AND status IN ('queued','researched','new')`
      ).bind(m.institution_id).run();
      await logEvent(env, m.thread_id, 'sent', { to: m.to_addr, subject: m.subject });
      sent++;
    } catch (err) {
      await env.DB.prepare("UPDATE messages SET status = 'failed', status_detail = ? WHERE id = ?")
        .bind(String(err.message).slice(0, 400), m.id)
        .run();
      await logEvent(env, m.thread_id, 'send_failed', { error: String(err.message) });
      failures.push({ to: m.to_addr, error: String(err.message) });
    }
  }

  return { sent, failures };
}

// ---------------------------------------------------------------------------
// 10. Inbound mail.
// ---------------------------------------------------------------------------
//
// Resend's inbound webhook delivers parsed JSON, so there is no MIME to walk:
// no multipart traversal, no quoted-printable decoding, no charset guessing.
// That removed the most fragile code in this file. What remains is stripping
// the quoted history and verifying the webhook is genuinely from Resend.

const stripHtml = (s) =>
  s
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/p>/gi, '\n\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\n{3,}/g, '\n\n')
    .trim();

/**
 * Drops the quoted history so the agent reasons about the new text only.
 * Without this the model re-answers its own previous email.
 */
function stripQuotedReply(text) {
  const cuts = [
    /^On .+ wrote:$/m,
    /^-{2,}\s*Original Message\s*-{2,}$/im,
    /^_{5,}$/m,
    /^From:\s.+$/m,
    /^>{1,}\s?/m,
  ];
  let end = text.length;
  for (const re of cuts) {
    const m = text.match(re);
    if (m && m.index !== undefined && m.index < end) end = m.index;
  }
  return text.slice(0, end).trim();
}

const addrOf = (v) => (String(v || '').match(/<([^>]+)>/)?.[1] || String(v || '')).trim().toLowerCase();

const stripAngle = (v) => String(v || '').replace(/^<|>$/g, '').trim();

/**
 * Verifies a Svix-signed webhook, which is what Resend uses.
 *
 * This endpoint takes no admin token - it has to be reachable by Resend - so
 * the signature is the only thing standing between a stranger and the ability
 * to inject fake replies into the pipeline. It is not optional.
 */
async function verifyResendWebhook(env, request, rawBody) {
  const secret = env.RESEND_WEBHOOK_SECRET;
  if (!secret) throw new Error('RESEND_WEBHOOK_SECRET is not configured');

  const id = request.headers.get('svix-id');
  const timestamp = request.headers.get('svix-timestamp');
  const signature = request.headers.get('svix-signature');
  if (!id || !timestamp || !signature) throw new Error('missing svix headers');

  // Reject stale deliveries so a captured request cannot be replayed later.
  const age = Math.abs(Date.now() / 1000 - Number(timestamp));
  if (!Number.isFinite(age) || age > 300) throw new Error('webhook timestamp outside tolerance');

  const raw = secret.startsWith('whsec_') ? secret.slice(6) : secret;
  const keyBytes = Uint8Array.from(atob(raw), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey('raw', keyBytes, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const mac = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(`${id}.${timestamp}.${rawBody}`));
  const expected = btoa(String.fromCharCode(...new Uint8Array(mac)));

  // The header carries a space-separated list of "v1,<sig>" entries.
  const presented = signature.split(' ').map((p) => p.split(',')[1]).filter(Boolean);
  if (!presented.some((sig) => tokenMatches(sig, expected))) throw new Error('webhook signature mismatch');
}

/**
 * Normalises a received-email object into the shape handleInbound expects.
 * Header collections arrive either as [{name,value}] or as a plain object
 * depending on the endpoint, so both are accepted.
 */
function normalizeInbound(d = {}) {
  const headers = {};
  if (Array.isArray(d.headers)) {
    for (const h of d.headers) if (h?.name) headers[String(h.name).toLowerCase()] = h.value;
  } else if (d.headers && typeof d.headers === 'object') {
    for (const [k, v] of Object.entries(d.headers)) headers[k.toLowerCase()] = v;
  }
  const text = d.text || (d.html ? stripHtml(d.html) : '');
  const refs = `${headers['in-reply-to'] || ''} ${headers['references'] || ''}`;
  return {
    from: addrOf(Array.isArray(d.from) ? d.from[0] : d.from),
    subject: d.subject || '',
    text: stripQuotedReply(text || ''),
    messageId: stripAngle(d.message_id || headers['message-id']),
    // Newest first: the immediate parent is the most likely thread match.
    referenced: [...refs.matchAll(/<([^>]+)>/g)].map((m) => m[1]).reverse(),
  };
}

/**
 * Resolves a webhook delivery into a full message.
 *
 * The email.received webhook carries metadata only - no body - so the content
 * has to be fetched from the receiving API. Resend stores the message even if
 * this endpoint is down, so a failed fetch is recoverable rather than lost.
 */
async function fetchInbound(env, payload) {
  const d = payload?.data || payload || {};
  if (d.text || d.html) return normalizeInbound(d);

  // Field naming has moved around; accept the plausible spellings rather than
  // failing on one guess. If none match, the error names what we did receive.
  const emailId =
    d.id || d.email_id || d.emailId || d.inbound_id || d.message_id ||
    payload?.id || payload?.email_id || null;
  if (!emailId) {
    throw new Error(
      `inbound webhook carried no body and no recognisable id. ` +
      `type=${payload?.type || 'none'} data keys=[${Object.keys(d).join(', ')}] ` +
      `top keys=[${Object.keys(payload || {}).join(', ')}]`
    );
  }
  if (!env.RESEND_API_KEY) throw new Error('RESEND_API_KEY is not configured');

  const res = await fetch(`https://api.resend.com/emails/receiving/${encodeURIComponent(emailId)}`, {
    headers: { authorization: `Bearer ${env.RESEND_API_KEY}` },
  });
  const body = await res.text();
  if (!res.ok) throw new Error(`Resend receiving ${res.status}: ${body.slice(0, 200)}`);
  let full;
  try {
    full = JSON.parse(body);
  } catch {
    throw new Error('Resend receiving returned non-JSON');
  }
  return normalizeInbound(full.data || full);
}

// ---------------------------------------------------------------------------
// 11. The reply agent.
// ---------------------------------------------------------------------------

/**
 * Classifies an inbound reply and decides who answers it. Deliberately biased
 * toward escalation: the cost of a wrong autonomous answer to a compliance
 * officer is far higher than the cost of you reading one extra email.
 */
async function classifyReply(env, inst, text) {
  const system = `You triage replies to a B2B outreach email and decide whether an AI may answer or a human must.
${HONESTY}

Intents:
  faq                       - a question answerable from the FAQ you were given, and only from it
  scheduling                - wants a call, asks about times
  unsubscribe               - wants no further contact, in any wording
  out_of_office             - automatic absence reply
  wrong_person              - redirects you to a colleague
  not_interested            - a clear no, without hostility
  pricing_negotiation       - discounts, custom terms, budget shaping
  contract_or_legal         - contracts, terms, liability, MSAs
  security_or_privacy_review- security questionnaires, SOC 2, pen tests, data residency
  data_processing_agreement - DPA, GDPR, processor terms
  procurement_or_rfp        - vendor onboarding, RFP/RFI, purchasing process
  accessibility_compliance  - accessibility or conformance requirements
  integration_commitment    - asks you to commit to building or supporting something
  timeline_commitment       - asks you to commit to a delivery date
  complaint_or_hostile      - annoyed, accusatory, or threatening
  other                     - anything else

Rules:
- If a reply mixes intents, return the single most consequential one.
- A question you cannot answer word-for-word from the FAQ is NOT faq. Use other.
- When genuinely unsure, prefer the intent that sends it to a human.

Return ONLY JSON:
{"intent":"<one of the above>","confidence":0.0-1.0,"summary":"<=25 words","asks":["the specific questions they asked"]}`;

  const user = `${productBrief()}

FAQ the agent is allowed to answer from:
${PRODUCT.faq.map((f, i) => `${i + 1}. Q: ${f.q}\n   A: ${f.a}`).join('\n')}

Institution: ${inst?.name || 'unknown'} (${inst?.vertical || 'unknown'})

Their reply:
"""
${text.slice(0, 4000)}
"""`;

  const out = await ai(env, system, user, { maxTokens: 400, temperature: 0.1 });
  const parsed = extractJson(out) || {};
  return {
    intent: parsed.intent || 'other',
    confidence: Number(parsed.confidence) || 0,
    summary: parsed.summary || '',
    asks: Array.isArray(parsed.asks) ? parsed.asks : [],
  };
}

/**
 * The autonomy gate. You chose "auto-reply on simple cases, escalate the rest",
 * and this is where that is enforced - one function, easy to audit, easy to
 * tighten. Everything not explicitly allowed goes to a human by default.
 */
function mayAutoReply(triage) {
  if (ESCALATE_ALWAYS.includes(triage.intent)) return { ok: false, why: `${triage.intent} always needs a human` };
  if (!AUTO_OK.includes(triage.intent)) return { ok: false, why: `intent "${triage.intent}" is not on the auto-reply list` };
  // A confident wrong answer is the failure mode worth guarding against.
  if (triage.confidence < 0.75) return { ok: false, why: `low confidence (${triage.confidence.toFixed(2)})` };
  return { ok: true };
}

async function draftReply(env, inst, contact, triage, history) {
  const system = `You are the assistant handling replies for ${PRODUCT.name}. You are writing to a named person at a financial institution.
${HONESTY}

Additional rules for replies:
- Answer ONLY from the FAQ and the product facts you were given. Nothing else.
- Never quote a price other than list price, never offer a discount, never agree to a deadline,
  never confirm a security posture, and never accept contract terms. Those are not yours to give.
- If they asked something you cannot answer from your material, say a colleague will follow up
  with specifics - do not improvise an answer.
- 60-110 words. Plain text. No markdown, no bullets, no signature.
- Match their register: brief if they were brief.

Return ONLY JSON: {"body": "..."}`;

  const user = `${productBrief()}

FAQ:
${PRODUCT.faq.map((f) => `Q: ${f.q}\nA: ${f.a}`).join('\n\n')}

Institution: ${inst.name} (${inst.vertical})
Person: ${contact.name || 'unknown'}, ${contact.title || 'title unknown'}
Triage: intent=${triage.intent}, summary=${triage.summary}
They asked: ${triage.asks.join(' | ') || 'nothing specific'}

Conversation so far (oldest first):
${history.map((m) => `[${m.direction === 'outbound' ? 'us' : 'them'}] ${m.body.slice(0, 700)}`).join('\n\n')}`;

  const out = await ai(env, system, user, { maxTokens: 500, temperature: 0.4, role: "write" });
  const parsed = extractJson(out);
  if (!parsed?.body) throw new Error('Reply generation returned no body');
  return String(parsed.body).trim();
}

/** Tells you a thread needs attention, using the same SMTP path as everything else. */
async function notifyHuman(env, inst, contact, thread, triage, text) {
  if (!env.OPERATOR_EMAIL) return;
  const body =
    `${inst.name} (${inst.vertical}) replied and the agent handed it to you.\n\n` +
    `Reason: ${triage.escalationReason}\n` +
    `Intent: ${triage.intent} (confidence ${triage.confidence.toFixed(2)})\n` +
    `Summary: ${triage.summary}\n` +
    `From: ${contact.name || contact.email} <${contact.email}>\n\n` +
    `--- their message ---\n${text.slice(0, 1500)}\n\n` +
    `Open: ${env.PUBLIC_BASE_URL}/thread/${thread.id}`;

  try {
    await sendMail(env, {
      from: sender(env).fromEmail,
      fromName: `${PRODUCT.name} agent`,
      to: env.OPERATOR_EMAIL,
      subject: `[needs you] ${inst.name} - ${triage.intent}`,
      body,
    });
  } catch (err) {
    // Never let a failed notification lose the escalation; the thread is
    // already marked needs_human in the database and shows on the dashboard.
    await logEvent(env, thread.id, 'notify_failed', { error: String(err.message) });
  }
}

/**
 * The full inbound path: match to a thread, triage, then answer or escalate.
 * `msg` is the normalised shape from normalizeInbound().
 */
async function handleInbound(env, msg) {
  const from = msg.from;
  const text = msg.text;

  // Match the reply to its thread via RFC 5322 threading headers, falling back
  // to the most recent thread with this contact when a client rewrites them.
  // The fallback carries more weight here than it did on SMTP: Resend assigns
  // its own message ids, so header matching succeeds less often.
  let thread = null;
  for (const mid of msg.referenced || []) {
    thread = await env.DB.prepare(
      `SELECT t.* FROM threads t JOIN messages m ON m.thread_id = t.id WHERE m.message_id = ? LIMIT 1`
    ).bind(mid).first();
    if (thread) break;
  }
  if (!thread) {
    thread = await env.DB.prepare(
      `SELECT t.* FROM threads t JOIN contacts c ON c.id = t.contact_id
        WHERE lower(c.email) = ? ORDER BY t.last_activity DESC LIMIT 1`
    ).bind(from).first();
  }
  if (!thread) return { ignored: 'no matching thread', from };

  const inst = await env.DB.prepare('SELECT * FROM institutions WHERE id = ?').bind(thread.institution_id).first();
  const contact = await env.DB.prepare('SELECT * FROM contacts WHERE id = ?').bind(thread.contact_id).first();

  await env.DB.prepare(
    `INSERT INTO messages (id, thread_id, direction, from_addr, to_addr, subject, body, message_id, status, authored_by)
     VALUES (?, ?, 'inbound', ?, ?, ?, ?, ?, 'received', 'contact')`
  ).bind(
    uid(), thread.id, from, sender(env).fromEmail,
    msg.subject || thread.subject, text, msg.messageId || null
  ).run();

  const triage = await classifyReply(env, inst, text);
  await logEvent(env, thread.id, 'inbound_triaged', triage);

  // Honour an opt-out immediately and unconditionally, before anything else
  // in the pipeline gets a chance to queue another message.
  if (triage.intent === 'unsubscribe') {
    await suppress(env, from, 'unsubscribe');
    await env.DB.prepare("UPDATE threads SET state = 'unsubscribed', owner = 'human', last_activity = datetime('now') WHERE id = ?")
      .bind(thread.id).run();
    await env.DB.prepare("UPDATE institutions SET status = 'suppressed' WHERE id = ?").bind(thread.institution_id).run();
    // Cancel anything already waiting in the queue for this thread.
    await env.DB.prepare("UPDATE messages SET status = 'failed', status_detail = 'unsubscribed' WHERE thread_id = ? AND status = 'queued'")
      .bind(thread.id).run();
    await logEvent(env, thread.id, 'unsubscribed', { email: from });
    return { thread: thread.id, action: 'unsubscribed' };
  }

  // Auto-replies to auto-replies is how mail loops start.
  if (triage.intent === 'out_of_office') {
    await env.DB.prepare("UPDATE threads SET last_activity = datetime('now') WHERE id = ?").bind(thread.id).run();
    return { thread: thread.id, action: 'ignored_auto_reply' };
  }

  const gate = mayAutoReply(triage);
  if (!gate.ok) {
    triage.escalationReason = gate.why;
    await env.DB.prepare(
      `UPDATE threads SET state = 'needs_human', owner = 'human', escalation_reason = ?, last_activity = datetime('now') WHERE id = ?`
    ).bind(gate.why, thread.id).run();
    await env.DB.prepare("UPDATE institutions SET status = 'escalated', updated_at = datetime('now') WHERE id = ?")
      .bind(thread.institution_id).run();
    await logEvent(env, thread.id, 'escalated', { reason: gate.why, intent: triage.intent });
    await notifyHuman(env, inst, contact, thread, triage, text);
    return { thread: thread.id, action: 'escalated', reason: gate.why };
  }

  // A clear no is respected rather than answered. Nothing to gain by replying.
  if (triage.intent === 'not_interested') {
    await env.DB.prepare("UPDATE threads SET state = 'closed_lost', owner = 'human', last_activity = datetime('now') WHERE id = ?")
      .bind(thread.id).run();
    await env.DB.prepare("UPDATE institutions SET status = 'lost', updated_at = datetime('now') WHERE id = ?")
      .bind(thread.institution_id).run();
    return { thread: thread.id, action: 'closed_lost' };
  }

  const { results: history } = await env.DB.prepare(
    'SELECT direction, body FROM messages WHERE thread_id = ? ORDER BY created_at'
  ).bind(thread.id).all();

  const replyBody = await draftReply(env, inst, contact, triage, history || []);
  const lastOutbound = await env.DB.prepare(
    `SELECT message_id FROM messages WHERE thread_id = ? AND direction = 'outbound' AND message_id IS NOT NULL
      ORDER BY created_at DESC LIMIT 1`
  ).bind(thread.id).first();

  await env.DB.prepare(
    `INSERT INTO messages (id, thread_id, direction, from_addr, to_addr, subject, body, in_reply_to, status, authored_by, send_after)
     VALUES (?, ?, 'outbound', ?, ?, ?, ?, ?, 'queued', 'agent', datetime('now', '+4 minutes'))`
  ).bind(
    uid(), thread.id, sender(env).fromEmail, contact.email,
    thread.subject.startsWith('Re:') ? thread.subject : `Re: ${thread.subject}`,
    replyBody, msg.messageId || lastOutbound?.message_id || null
  ).run();

  await env.DB.prepare("UPDATE threads SET state = 'agent_handling', last_activity = datetime('now') WHERE id = ?")
    .bind(thread.id).run();
  await env.DB.prepare("UPDATE institutions SET status = 'engaged', updated_at = datetime('now') WHERE id = ?")
    .bind(thread.institution_id).run();
  await logEvent(env, thread.id, 'auto_reply_queued', { intent: triage.intent });

  return { thread: thread.id, action: 'auto_replied', intent: triage.intent };
}

// ---------------------------------------------------------------------------
// 12. Follow-ups.
// ---------------------------------------------------------------------------

/**
 * Two follow-ups, then stop. Institutional buyers are slow, not rude; chasing
 * harder than this converts nothing and costs you the domain.
 */
async function queueFollowUps(env) {
  const { results } = await env.DB.prepare(
    `SELECT t.*, c.email, c.name AS contact_name, i.name AS inst_name, i.vertical,
            (SELECT COUNT(*) FROM messages m WHERE m.thread_id = t.id AND m.direction = 'outbound') AS out_count,
            (SELECT COUNT(*) FROM messages m WHERE m.thread_id = t.id AND m.direction = 'inbound')  AS in_count
       FROM threads t
       JOIN contacts c ON c.id = t.contact_id
       JOIN institutions i ON i.id = t.institution_id
      WHERE t.state = 'awaiting_reply'
        AND t.last_activity < datetime('now', ?)`
  ).bind(`-${LIMITS.followUpDelayDays} days`).all();

  let queued = 0;
  for (const t of results || []) {
    if (t.in_count > 0) continue;                              // they replied; not a follow-up case
    if (t.out_count > LIMITS.maxFollowUps) continue;           // opening message plus the allowance
    if (await isSuppressed(env, t.email)) continue;

    const isLast = t.out_count === LIMITS.maxFollowUps;
    const system = `You write a short follow-up to an unanswered first email to a senior person at a financial institution.
${HONESTY}
- 35-60 words, plain text, no signature.
- Add one new specific thing; never simply "bumping this".
- No guilt, no false urgency, no "just checking in".
${isLast ? '- This is the last message. Say plainly that you will stop here, and leave the door open.' : ''}
Return ONLY JSON: {"body":"..."}`;

    const angle = angleFor(t.vertical);
    const out = await ai(
      env,
      system,
      `${productBrief()}\n\nTo: ${t.contact_name || 'them'} at ${t.inst_name}\nOriginal subject: ${t.subject}\n${angle ? `Angle: ${angle.outcome}` : ''}`,
      { maxTokens: 300, temperature: 0.6, role: "write" }
    );
    const parsed = extractJson(out);
    if (!parsed?.body) continue;

    const last = await env.DB.prepare(
      `SELECT message_id FROM messages WHERE thread_id = ? AND direction = 'outbound' AND message_id IS NOT NULL
        ORDER BY created_at DESC LIMIT 1`
    ).bind(t.id).first();

    await env.DB.prepare(
      `INSERT INTO messages (id, thread_id, direction, from_addr, to_addr, subject, body, in_reply_to, status, authored_by, send_after)
       VALUES (?, ?, 'outbound', ?, ?, ?, ?, ?, 'queued', 'agent', datetime('now'))`
    ).bind(
      uid(), t.id, sender(env).fromEmail, t.email,
      t.subject.startsWith('Re:') ? t.subject : `Re: ${t.subject}`,
      String(parsed.body).trim(), last?.message_id || null
    ).run();

    await env.DB.prepare("UPDATE threads SET last_activity = datetime('now') WHERE id = ?").bind(t.id).run();
    await logEvent(env, t.id, 'followup_queued', { n: t.out_count });
    queued++;
  }
  return { queued };
}

// ---------------------------------------------------------------------------
// 13. HTTP surface.
// ---------------------------------------------------------------------------

/** Constant-time compare so the admin token cannot be recovered by timing. */
function tokenMatches(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function authorized(request, env) {
  const secret = env.ADMIN_TOKEN || '';
  // Fail closed when the token is unset or trivially short. Without this an
  // empty presented value compares equal to an empty secret and the dashboard,
  // the whole target list and every API route are open to anyone who finds the
  // workers.dev URL.
  if (secret.length < 16) return false;
  const url = new URL(request.url);
  const presented = request.headers.get('authorization')?.replace(/^Bearer\s+/i, '') || url.searchParams.get('k') || '';
  return tokenMatches(presented, secret);
}

const PAGE_CSS = `
:root{--bg:#fbfbfa;--fg:#1c1c1a;--mut:#6b6b66;--line:#e3e3df;--card:#fff;--acc:#1a5c47;--warn:#8a4b1f}
@media(prefers-color-scheme:dark){:root{--bg:#16181a;--fg:#e8e8e4;--mut:#9a9a94;--line:#2c2f33;--card:#1e2124;--acc:#5fbfa0;--warn:#d99a5b}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.55 ui-sans-serif,system-ui,-apple-system,Segoe UI,sans-serif}
.wrap{max-width:1080px;margin:0 auto;padding:32px 20px}
h1{font-size:20px;margin:0 0 4px}h2{font-size:15px;margin:32px 0 10px;letter-spacing:.02em;text-transform:uppercase;color:var(--mut)}
.sub{color:var(--mut);margin:0 0 24px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-bottom:8px}
.stat{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px}
.stat b{display:block;font-size:24px;font-weight:600}.stat span{color:var(--mut);font-size:12px}
.banner{background:var(--card);border:1px solid var(--warn);border-left:3px solid var(--warn);border-radius:8px;padding:12px 14px;margin-bottom:20px}
table{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);border-radius:10px;overflow:hidden}
th,td{text-align:left;padding:9px 12px;border-bottom:1px solid var(--line);vertical-align:top}
th{font-size:11px;text-transform:uppercase;letter-spacing:.04em;color:var(--mut)}
tr:last-child td{border-bottom:none}
.scroll{overflow-x:auto}
.pill{display:inline-block;padding:1px 7px;border-radius:99px;font-size:11px;border:1px solid var(--line);color:var(--mut)}
.pill.hot{color:var(--acc);border-color:var(--acc)}.pill.esc{color:var(--warn);border-color:var(--warn)}
code{background:var(--line);padding:1px 5px;border-radius:4px;font-size:12px}
a{color:var(--acc)}`;

function page(title, inner) {
  return html(`<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(title)}</title><style>${PAGE_CSS}</style><div class="wrap">${inner}</div>`);
}

async function dashboard(env, key) {
  const q = (sql, ...b) => env.DB.prepare(sql).bind(...b).first();
  const counts = await Promise.all([
    q("SELECT COUNT(*) n FROM institutions"),
    q("SELECT COUNT(*) n FROM institutions WHERE status = 'contacted'"),
    q("SELECT COUNT(*) n FROM institutions WHERE status = 'engaged'"),
    q("SELECT COUNT(*) n FROM threads WHERE state = 'needs_human'"),
    q("SELECT COUNT(*) n FROM messages WHERE status = 'queued'"),
    q("SELECT COUNT(*) n FROM suppressions"),
  ]);
  const [all, contacted, engaged, needsHuman, queued, suppressed] = counts.map((r) => r?.n || 0);

  const gaps = productGaps(env);
  // Deliberately not alarming: an incomplete profile blocks sending and nothing
  // else, so scoring, pitch generation and review all stay usable while you
  // decide on the missing pieces.
  const banner = gaps.length
    ? `<div class="banner"><b>Nothing will send yet.</b> Scoring, pitch writing, queueing and the reply agent
       all work - only the outbound queue is held, until these are set:
       <code>${gaps.map(esc).join('</code> <code>')}</code>.
       Variables live in Worker Settings; product fields live in <code>PRODUCT</code> at the top of <code>worker.js</code>.</div>`
    : '';

  const withheld = withheldClaims();
  const claimBanner = withheld.length
    ? `<div class="banner"><b>Withheld from the agent.</b> These claims are not yet substantiated, so they are
       kept out of every prompt and cannot be cited: <code>${withheld.map(esc).join('</code> <code>')}</code>.
       Sequences still send - they stand on the substantiated points. See <code>docs/EVIDENCE.md</code>.</div>`
    : '';

  const { results: escalations } = await env.DB.prepare(
    `SELECT t.id, t.subject, t.escalation_reason, t.last_activity, i.name inst, i.vertical
       FROM threads t JOIN institutions i ON i.id = t.institution_id
      WHERE t.state = 'needs_human' ORDER BY t.last_activity DESC LIMIT 25`
  ).all();

  const { results: top } = await env.DB.prepare(
    `SELECT id, name, vertical, fit_score, fit_reason, fit_risks, status
       FROM institutions WHERE fit_score IS NOT NULL
      ORDER BY fit_score DESC LIMIT 25`
  ).all();

  return page(
    `${PRODUCT.name} outreach`,
    `<h1>${esc(PRODUCT.name)} outreach</h1>
     <p class="sub">${esc(PRODUCT.oneLiner)}</p>
     ${banner}
     ${claimBanner}
     <div class="grid">
       <div class="stat"><b>${all}</b><span>institutions</span></div>
       <div class="stat"><b>${contacted}</b><span>contacted</span></div>
       <div class="stat"><b>${engaged}</b><span>engaged</span></div>
       <div class="stat"><b>${needsHuman}</b><span>need you</span></div>
       <div class="stat"><b>${queued}</b><span>queued to send</span></div>
       <div class="stat"><b>${suppressed}</b><span>suppressed</span></div>
     </div>

     <h2>Waiting on you</h2>
     ${
       escalations?.length
         ? `<div class="scroll"><table><tr><th>Institution</th><th>Why it escalated</th><th>When</th></tr>
            ${escalations.map((e) => `<tr><td><a href="/thread/${esc(e.id)}?k=${encodeURIComponent(key)}">${esc(e.inst)}</a><br><span class="pill">${esc(e.vertical)}</span></td><td>${esc(e.escalation_reason || '')}</td><td>${esc(e.last_activity)}</td></tr>`).join('')}
            </table></div>`
         : '<p class="sub">Nothing escalated. The agent is handling what has come in.</p>'
     }

     <h2>Best fit</h2>
     ${
       top?.length
         ? `<div class="scroll"><table><tr><th>Institution</th><th>Score</th><th>Why</th><th>Risk</th><th>Status</th></tr>
            ${top.map((i) => `<tr><td>${esc(i.name)}<br><span class="pill">${esc(i.vertical)}</span></td>
              <td><span class="pill ${i.fit_score >= 75 ? 'hot' : ''}">${i.fit_score}</span></td>
              <td>${esc(i.fit_reason || '')}</td><td>${esc(i.fit_risks || '')}</td><td>${esc(i.status)}</td></tr>`).join('')}
            </table></div>`
         : '<p class="sub">No institutions scored yet. POST to <code>/api/score-all</code> to run the fit pass.</p>'
     }`
  );
}

async function threadView(env, id, key) {
  const t = await env.DB.prepare(
    `SELECT t.*, i.name inst, i.vertical, i.fit_reason, i.fit_risks, c.email, c.name cname, c.title
       FROM threads t JOIN institutions i ON i.id = t.institution_id JOIN contacts c ON c.id = t.contact_id
      WHERE t.id = ?`
  ).bind(id).first();
  if (!t) return page('Not found', '<h1>Thread not found</h1>');

  const { results: msgs } = await env.DB.prepare(
    'SELECT * FROM messages WHERE thread_id = ? ORDER BY created_at'
  ).bind(id).all();

  return page(
    t.subject,
    `<p><a href="/?k=${encodeURIComponent(key)}">&larr; back</a></p>
     <h1>${esc(t.inst)}</h1>
     <p class="sub">${esc(t.cname || t.email)}${t.title ? `, ${esc(t.title)}` : ''} &middot;
       <span class="pill ${t.state === 'needs_human' ? 'esc' : ''}">${esc(t.state)}</span>
       ${t.escalation_reason ? `&middot; ${esc(t.escalation_reason)}` : ''}</p>
     <h2>Conversation</h2>
     ${msgs.map((m) => `<div class="stat" style="margin-bottom:8px">
        <span class="pill">${m.direction === 'outbound' ? `us &middot; ${esc(m.authored_by)} &middot; ${esc(m.status)}` : 'them'}</span>
        <div style="margin-top:8px;white-space:pre-wrap">${esc(m.body)}</div></div>`).join('')}
     <h2>Reply yourself</h2>
     <form method="POST" action="/thread/${esc(id)}/reply?k=${encodeURIComponent(key)}">
       <textarea name="body" rows="8" style="width:100%;padding:10px;border:1px solid var(--line);border-radius:8px;background:var(--card);color:var(--fg);font:inherit" placeholder="Written by you, queued and sent through the same path as everything else."></textarea>
       <p><button style="padding:8px 16px;border-radius:8px;border:1px solid var(--acc);background:var(--acc);color:#fff;font:inherit;cursor:pointer">Queue reply</button></p>
     </form>`
  );
}

// ---------------------------------------------------------------------------
// 14. Entry points.
// ---------------------------------------------------------------------------

export default {
  async fetch(request, env) {
    // A bare 1101 tells you nothing and costs a round trip to the Logs tab
    // every time. Errors come back as JSON instead. Nothing secret reaches
    // here - D1 and Workers AI exceptions carry query and model detail only.
    try {
      return await route(request, env);
    } catch (err) {
      return json(
        {
          error: String(err?.message || err),
          where: String(err?.stack || '').split('\n').slice(0, 4),
        },
        500
      );
    }
  },

  /** Every 15 minutes: drain the send queue, then top up follow-ups hourly. */
  async scheduled(event, env, ctx) {
    ctx.waitUntil(
      (async () => {
        const drained = await drainQueue(env);
        console.log('drain', JSON.stringify(drained));
        if (new Date(event.scheduledTime).getUTCMinutes() < 15) {
          const followed = await queueFollowUps(env);
          console.log('followups', JSON.stringify(followed));
        }
      })()
    );
  },
};

/** All HTTP routing. Wrapped by fetch() above so exceptions surface as JSON. */
async function route(request, env) {
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, '') || '/';

    // Public, and deliberately so: an opt-out must never require a login.
    if (path === '/unsubscribe') {
      const contactId = url.searchParams.get('c') || '';
      const token = url.searchParams.get('t') || '';
      let expected = null;
      try {
        expected = contactId ? await unsubToken(env, contactId) : null;
      } catch {
        // Misconfigured secret. Show the fallback rather than an error page:
        // replying "unsubscribe" is honoured unconditionally by the agent, so
        // the recipient still has a working way out.
        expected = null;
      }
      if (!contactId || expected === null || !tokenMatches(token, expected)) {
        return page('Invalid link', '<h1>That unsubscribe link is not valid</h1><p class="sub">Reply to any of our emails with the word "unsubscribe" and we will remove you.</p>');
      }
      const contact = await env.DB.prepare('SELECT * FROM contacts WHERE id = ?').bind(contactId).first();
      if (contact) {
        await suppress(env, contact.email, 'unsubscribe');
        await env.DB.prepare(
          `UPDATE messages SET status = 'failed', status_detail = 'unsubscribed'
            WHERE status = 'queued' AND thread_id IN (SELECT id FROM threads WHERE contact_id = ?)`
        ).bind(contactId).run();
        await env.DB.prepare(
          `UPDATE threads SET state = 'unsubscribed', owner = 'human' WHERE contact_id = ?`
        ).bind(contactId).run();
        await logEvent(env, null, 'unsubscribed_via_link', { email: contact.email });
      }
      // The same page either way, so the link cannot be used to test whether an
      // address is in the database.
      return page('Unsubscribed', '<h1>Removed</h1><p class="sub">You will not hear from us again. Nothing further is needed from you.</p>');
    }

    /**
     * Resend inbound webhook. Public by necessity - Resend has no admin token -
     * so the Svix signature is the only thing preventing a stranger from
     * injecting fabricated replies into the pipeline.
     */
    if (path === '/webhook/resend' && request.method === 'POST') {
      const rawBody = await request.text();
      // Durable trail: console logs vanish unless you are watching live, and
      // "the forward never arrived" is unanswerable without knowing whether the
      // webhook was even called.
      // The raw body is recorded because the payload shape is the thing we keep
      // being wrong about, and it is small metadata about your own mail.
      await logEvent(env, null, 'webhook_received', {
        bytes: rawBody.length,
        raw: rawBody.slice(0, 1500),
      }).catch(() => {});
      try {
        await verifyResendWebhook(env, request, rawBody);
      } catch (err) {
        console.error('webhook rejected', String(err?.message || err));
        await logEvent(env, null, 'webhook_rejected', { reason: String(err?.message || err) }).catch(() => {});
        return json({ error: 'signature verification failed' }, 401);
      }

      let payload;
      try {
        payload = JSON.parse(rawBody);
      } catch {
        return json({ error: 'invalid JSON' }, 400);
      }
      if (payload?.type && payload.type !== 'email.received') {
        return json({ ignored: payload.type });
      }

      let msg;
      let fetchError = null;
      try {
        msg = await fetchInbound(env, payload);
      } catch (err) {
        fetchError = String(err?.message || err);
        console.error('inbound fetch failed', fetchError);
        await logEvent(env, null, 'inbound_fetch_failed', { error: fetchError }).catch(() => {});
      }

      // Even with no body, forward what the webhook itself carried. The whole
      // point of forwarding first was that you always see that a reply arrived;
      // returning early on a fetch failure defeated that, which is how a real
      // reply went silently missing.
      if (fetchError) {
        const d = payload?.data || {};
        if (env.FORWARD_TO) {
          try {
            await sendMail(env, {
              from: sender(env).fromEmail,
              fromName: `${PRODUCT.name} inbound`,
              to: env.FORWARD_TO,
              subject: `[reply received - body unavailable] ${d.subject || '(no subject)'}`,
              body:
                `A reply arrived but its body could not be retrieved from Resend.\n\n` +
                `From: ${Array.isArray(d.from) ? d.from.join(', ') : d.from || 'unknown'}\n` +
                `Subject: ${d.subject || '(none)'}\n` +
                `Resend id: ${d.id || 'unknown'}\n\n` +
                `Error: ${fetchError}\n\n` +
                `The message is still stored in Resend - read it at https://resend.com/emails`,
            });
            await logEvent(env, null, 'forwarded_metadata_only', { id: d.id }).catch(() => {});
          } catch (err) {
            await logEvent(env, null, 'forward_failed', { error: String(err?.message || err) }).catch(() => {});
          }
        }
        return json({ handled: false, error: fetchError, forwarded: !!env.FORWARD_TO });
      }

      // Forward a copy before anything else runs. A bug in triage must never be
      // the reason a reply from an institution never reaches you.
      if (env.FORWARD_TO) {
        try {
          await sendMail(env, {
            from: sender(env).fromEmail,
            fromName: `${PRODUCT.name} inbound`,
            replyTo: msg.from,
            to: env.FORWARD_TO,
            subject: `[reply] ${msg.subject || '(no subject)'}`,
            body: `From: ${msg.from}\n\n${msg.text}`,
          });
          await logEvent(env, null, 'forwarded', { to: env.FORWARD_TO, from: msg.from }).catch(() => {});
        } catch (err) {
          // Recorded rather than only logged: this is the failure the operator
          // notices ("no copy arrived") and it needs an answer they can query.
          console.error('forward failed', String(err?.message || err));
          await logEvent(env, null, 'forward_failed', {
            to: env.FORWARD_TO,
            error: String(err?.message || err),
          }).catch(() => {});
        }
      } else {
        await logEvent(env, null, 'forward_skipped', { reason: 'FORWARD_TO not set' }).catch(() => {});
      }

      try {
        const result = await handleInbound(env, msg);
        console.log('inbound', JSON.stringify(result));
        return json(result);
      } catch (err) {
        // Always 200 back to Resend: a non-2xx triggers their retries, and a
        // deterministic bug would then replay the same failure indefinitely.
        console.error('inbound failed', err?.stack || String(err));
        await logEvent(env, null, 'inbound_error', { error: String(err?.message || err) }).catch(() => {});
        return json({ handled: false, error: String(err?.message || err) });
      }
    }

    if (!authorized(request, env)) return new Response('Unauthorized', { status: 401 });
    const key = url.searchParams.get('k') || '';

    if (path === '/') return dashboard(env, key);

    const threadMatch = path.match(/^\/thread\/([^/]+)$/);
    if (threadMatch) return threadView(env, threadMatch[1], key);

    const replyMatch = path.match(/^\/thread\/([^/]+)\/reply$/);
    if (replyMatch && request.method === 'POST') {
      const form = await request.formData();
      const body = String(form.get('body') || '').trim();
      if (!body) return Response.redirect(`${env.PUBLIC_BASE_URL}/thread/${replyMatch[1]}?k=${encodeURIComponent(key)}`, 302);
      const t = await env.DB.prepare(
        'SELECT t.*, c.email FROM threads t JOIN contacts c ON c.id = t.contact_id WHERE t.id = ?'
      ).bind(replyMatch[1]).first();
      if (!t) return new Response('Not found', { status: 404 });
      const last = await env.DB.prepare(
        `SELECT message_id FROM messages WHERE thread_id = ? AND direction = 'outbound' AND message_id IS NOT NULL
          ORDER BY created_at DESC LIMIT 1`
      ).bind(t.id).first();
      await env.DB.prepare(
        `INSERT INTO messages (id, thread_id, direction, from_addr, to_addr, subject, body, in_reply_to, status, authored_by, send_after)
         VALUES (?, ?, 'outbound', ?, ?, ?, ?, ?, 'queued', 'human', datetime('now'))`
      ).bind(
        uid(), t.id, sender(env).fromEmail, t.email,
        t.subject.startsWith('Re:') ? t.subject : `Re: ${t.subject}`, body, last?.message_id || null
      ).run();
      await env.DB.prepare("UPDATE threads SET state = 'awaiting_reply', last_activity = datetime('now') WHERE id = ?")
        .bind(t.id).run();
      await logEvent(env, t.id, 'human_reply_queued', {});
      return Response.redirect(`${env.PUBLIC_BASE_URL}/thread/${t.id}?k=${encodeURIComponent(key)}`, 302);
    }

    // --- JSON API -----------------------------------------------------------

    /**
     * Checks each dependency in isolation and reports which one fails. Exists
     * because a single 1101 for the whole request tells you nothing about
     * whether the database, the AI binding, or the model name is at fault.
     */
    if (path === '/api/diag') {
      const out = {
        bindings: { DB: !!env.DB, AI: !!env.AI },
        model: modelFor(env),
        writeModel: modelFor(env, 'write'),
        modelSource: env.AI_MODEL ? 'AI_MODEL variable' : 'built-in default',
        // Presence only for secrets - never the values. "Is it set" is the
        // question that actually blocks things, and it is safe to report.
        secrets: {
          RESEND_API_KEY: !!env.RESEND_API_KEY,
          RESEND_WEBHOOK_SECRET: !!env.RESEND_WEBHOOK_SECRET,
          ADMIN_TOKEN: !!env.ADMIN_TOKEN,
          UNSUB_SECRET: !!env.UNSUB_SECRET,
        },
        mail: {
          FROM_EMAIL: env.FROM_EMAIL || null,
          REPLY_TO: env.REPLY_TO || null,
          FORWARD_TO: env.FORWARD_TO || null,
          OPERATOR_EMAIL: env.OPERATOR_EMAIL || null,
        },
        // Confirms which build is actually deployed, so "did you re-paste it"
        // stops being a question anyone has to answer from memory.
        buildMarker: 'two-models-1',
      };
      try {
        const ev = await env.DB.prepare(
          `SELECT kind, COUNT(*) AS n FROM events
            WHERE created_at > datetime('now','-1 day') GROUP BY kind ORDER BY n DESC`
        ).all();
        out.eventsLast24h = ev.results || [];
      } catch (err) {
        out.eventsError = String(err?.message || err);
      }
      try {
        const r = await env.DB.prepare('SELECT COUNT(*) AS n FROM institutions').first();
        out.institutions = r?.n ?? null;
      } catch (err) {
        out.dbError = String(err?.message || err);
      }
      try {
        // Raw shape too, so an unfamiliar model response can be read directly
        // rather than inferred from a failure downstream.
        const raw = await env.AI.run(modelFor(env), {
          messages: [{ role: 'user', content: 'Reply with the single word OK.' }],
          max_tokens: 10,
          temperature: 0,
        });
        out.aiRawKeys = Object.keys(raw || {});
        out.aiRawSample = JSON.stringify(raw).slice(0, 200);
        out.aiSample = aiText(raw).trim();
      } catch (err) {
        out.aiError = String(err?.message || err);
      }
      return json(out);
    }

    /**
     * Tries each candidate model with a one-token prompt and reports which
     * actually work on this account. Model ids get renamed and retired, and
     * finding out through a failed pitch generation is the slow way.
     */
    if (path === '/api/models') {
      const candidates = [
        '@cf/meta/llama-3.3-70b-instruct-fp8-fast',
        '@cf/mistralai/mistral-small-3.1-24b-instruct',
        '@cf/meta/llama-3.1-8b-instruct-fast',
        '@cf/meta/llama-3.2-3b-instruct',
        ...(url.searchParams.get('also') ? [url.searchParams.get('also')] : []),
      ];
      const results = [];
      for (const id of candidates) {
        const started = Date.now();
        try {
          const raw = await env.AI.run(id, {
            messages: [{ role: 'user', content: 'Reply with the single word OK.' }],
            max_tokens: 10,
            temperature: 0,
          });
          results.push({ model: id, ok: true, ms: Date.now() - started, sample: aiText(raw).trim().slice(0, 40) });
        } catch (err) {
          results.push({ model: id, ok: false, error: String(err?.message || err).slice(0, 200) });
        }
      }
      return json({ inUse: { classify: modelFor(env), write: modelFor(env, 'write') }, results });
    }

    if (path === '/api/health') {
      return json({
        ok: true,
        product: PRODUCT.name,
        stage: PRODUCT.stage,
        sendingBlocked: productGaps(env),
        sentLast24h: await sentToday(env),
      });
    }

    /**
     * Bulk import. Body: {institutions:[{name, vertical, ..., contacts:[{email,...}]}]}
     *
     * Batched rather than one write per row: the Workers free plan allows 50
     * subrequests per request, and a 126-row list issued individually fails
     * partway and leaves the table half-populated. A batch is one subrequest
     * and is applied atomically, so an import either lands or it does not.
     */
    if (path === '/api/institutions' && request.method === 'POST') {
      const payload = await request.json();
      const rows = Array.isArray(payload) ? payload : payload.institutions || [];

      // Upsert on name so re-importing refreshes the list rather than
      // duplicating it. Scoring columns are deliberately not touched, so a
      // re-import never discards work already done.
      const instSql = env.DB.prepare(
        `INSERT INTO institutions (id, name, vertical, segment, country, region, website, size_metric, size_value, notes, priority)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(name) DO UPDATE SET
           vertical    = excluded.vertical,
           segment     = excluded.segment,
           country     = excluded.country,
           region      = excluded.region,
           website     = excluded.website,
           size_metric = excluded.size_metric,
           size_value  = excluded.size_value,
           notes       = excluded.notes,
           priority    = excluded.priority,
           updated_at  = datetime('now')`
      );
      const contactSql = env.DB.prepare(
        `INSERT INTO contacts (id, institution_id, name, title, email, source, is_primary)
         VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT (institution_id, email) DO NOTHING`
      );

      const stmts = [];
      let added = 0;
      const skipped = [];
      for (const r of rows) {
        if (!r.name || !r.vertical) { skipped.push(r.name || '(unnamed)'); continue; }
        const id = r.id || uid();
        stmts.push(instSql.bind(
          id, r.name, r.vertical, r.segment || null, r.country || 'US', r.region || null,
          r.website || null, r.size_metric || null, r.size_value || null, r.notes || null,
          r.priority === undefined ? null : r.priority
        ));
        for (const c of r.contacts || []) {
          if (!c.email) continue;
          stmts.push(contactSql.bind(
            uid(), id, c.name || null, c.title || null, c.email.toLowerCase(),
            c.source || null, c.is_primary ? 1 : 0
          ));
        }
        added++;
      }

      // Chunked so a very large import cannot exceed a single batch's limits.
      for (let i = 0; i < stmts.length; i += 50) {
        await env.DB.batch(stmts.slice(i, i + 50));
      }
      return json({ added, statements: stmts.length, skipped });
    }

    /**
     * Adds contacts by institution NAME, so you never have to look up an id.
     * Body: {contacts:[{institution, email, name?, title?, source?}]}
     *
     * `source` is recorded and worth filling in honestly - if a procurement
     * officer ever asks where you got their address, the answer should exist.
     */
    if (path === '/api/contacts' && request.method === 'POST') {
      const payload = await request.json();
      const rows = Array.isArray(payload) ? payload : payload.contacts || [];
      const added = [];
      const skipped = [];

      for (const c of rows) {
        if (!c.institution || !c.email) {
          skipped.push({ input: c, reason: 'institution and email are both required' });
          continue;
        }
        const inst = await env.DB.prepare('SELECT id, name FROM institutions WHERE name = ?')
          .bind(c.institution).first();
        if (!inst) {
          skipped.push({ input: c.institution, reason: 'no institution with that exact name' });
          continue;
        }
        const email = String(c.email).toLowerCase().trim();
        if (await isSuppressed(env, email)) {
          skipped.push({ input: email, reason: 'suppressed - opted out' });
          continue;
        }
        // First contact for an institution becomes primary; that is the one
        // queuePitch writes to.
        const existing = await env.DB.prepare(
          'SELECT COUNT(*) AS n FROM contacts WHERE institution_id = ?'
        ).bind(inst.id).first();

        await env.DB.prepare(
          `INSERT INTO contacts (id, institution_id, name, title, email, source, is_primary)
           VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT (institution_id, email) DO NOTHING`
        ).bind(
          uid(), inst.id, c.name || null, c.title || null, email,
          c.source || null, (existing?.n || 0) === 0 ? 1 : 0
        ).run();
        added.push({ institution: inst.name, email });
      }
      return json({ added: added.length, skipped: skipped.length, details: { added, skipped } });
    }

    if (path === '/api/score-all' && request.method === 'POST') {
      const limit = Number(url.searchParams.get('limit') || 10);
      const { results } = await env.DB.prepare(
        "SELECT * FROM institutions WHERE fit_score IS NULL AND status = 'new' LIMIT ?"
      ).bind(limit).all();
      const scored = [];
      for (const inst of results || []) scored.push(await scoreFit(env, inst));
      return json({ scored });
    }

    /**
     * Writes opening emails and returns them WITHOUT queueing or needing a
     * contact row. This is how you read what the agent would say to a real
     * institution before any address exists to send it to - the target list
     * ships without email addresses on purpose, so /api/queue cannot run yet.
     */
    if (path === '/api/preview' && request.method === 'POST') {
      const id = url.searchParams.get('id');
      const minScore = Number(url.searchParams.get('min_score') || 70);
      const limit = Number(url.searchParams.get('limit') || 3);

      const { results } = id
        ? await env.DB.prepare('SELECT * FROM institutions WHERE id = ?').bind(id).all()
        : await env.DB.prepare(
            `SELECT * FROM institutions
              WHERE fit_score >= ? AND status NOT IN ('suppressed','lost')
              ORDER BY fit_score DESC LIMIT ?`
          ).bind(minScore, limit).all();

      const previews = [];
      for (const inst of results || []) {
        const angle = angleFor(inst.vertical);
        try {
          // A stand-in recipient: the pitch is addressed to the title the angle
          // says signs, which is who you would actually be writing to.
          const { subject, body } = await writePitch(env, inst, {
            name: null,
            title: angle?.buyerTitles?.[0] || null,
          });
          previews.push({
            institution: inst.name,
            vertical: inst.vertical,
            priority: inst.priority,
            score: inst.fit_score,
            wouldWriteTo: angle?.buyerTitles?.[0] || 'no angle defined',
            subject,
            body,
          });
        } catch (err) {
          previews.push({ institution: inst.name, error: String(err.message) });
        }
      }
      return json({ previews });
    }

    /**
     * Generates pitches and checks each against the rules that matter, so a
     * regression is caught mechanically rather than by reading 126 emails.
     * Only deterministic checks live here - anything needing judgement is left
     * to a human, because a model grading its own output proves nothing.
     */
    if (path === '/api/audit' && request.method === 'POST') {
      const limit = Number(url.searchParams.get('limit') || 5);
      const minScore = Number(url.searchParams.get('min_score') || 70);
      const { results } = await env.DB.prepare(
        `SELECT * FROM institutions
          WHERE fit_score >= ? AND status NOT IN ('suppressed','lost')
          ORDER BY fit_score DESC LIMIT ?`
      ).bind(minScore, limit).all();

      const report = [];
      for (const inst of results || []) {
        const angle = angleFor(inst.vertical);
        try {
          const { subject, body } = await writePitch(env, inst, {
            name: null,
            title: angle?.buyerTitles?.[0] || null,
          });
          const problems = pitchProblems(subject, body);
          const blocking = criticalProblems(problems);
          report.push({
            institution: inst.name,
            vertical: inst.vertical,
            score: inst.fit_score,
            words: body.trim().split(/\s+/).length,
            subject,
            verdict: blocking.length ? 'BLOCKED' : problems.length ? 'REVIEW' : 'clean',
            problems,
            body,
          });
        } catch (err) {
          report.push({ institution: inst.name, verdict: 'ERROR', problems: [String(err.message)] });
        }
      }
      const clean = report.filter((r) => r.verdict === 'clean').length;
      const blocked = report.filter((r) => r.verdict === 'BLOCKED').length;
      return json({ checked: report.length, clean, blocked, needsReview: report.length - clean, report });
    }

    /** Generates and queues the opening email. Nothing sends until the cron runs. */
    if (path === '/api/queue' && request.method === 'POST') {
      // ?name= accepts the institution name, so nobody has to copy a UUID out of
      // a console that wraps it across two lines.
      const wanted = url.searchParams.get('name');
      if (wanted) {
        const row = await env.DB.prepare('SELECT id FROM institutions WHERE name = ?')
          .bind(wanted.trim()).first();
        if (!row) {
          const near = await env.DB.prepare(
            "SELECT name FROM institutions WHERE name LIKE ? LIMIT 5"
          ).bind(`%${wanted.trim()}%`).all();
          return json(
            { error: `No institution named "${wanted}"`, didYouMean: (near.results || []).map((r) => r.name) },
            404
          );
        }
        return json(await queuePitch(env, row.id));
      }
      const id = (url.searchParams.get('id') || '').trim();
      const minScore = Number(url.searchParams.get('min_score') || 70);
      if (id) return json(await queuePitch(env, id));
      const limit = Number(url.searchParams.get('limit') || 5);
      const { results } = await env.DB.prepare(
        "SELECT id FROM institutions WHERE status = 'researched' AND fit_score >= ? ORDER BY fit_score DESC LIMIT ?"
      ).bind(minScore, limit).all();
      const out = [];
      for (const r of results || []) {
        try { out.push(await queuePitch(env, r.id)); }
        catch (err) { out.push({ id: r.id, error: String(err.message) }); }
      }
      return json({ queued: out });
    }

    /** Manual drain, for when you do not want to wait for the next cron tick. */
    if (path === '/api/drain' && request.method === 'POST') return json(await drainQueue(env));

    if (path === '/api/suppress' && request.method === 'POST') {
      const { email, scope = 'email', reason = 'manual' } = await request.json();
      await suppress(env, email, reason, scope);
      return json({ ok: true });
    }

    return new Response('Not found', { status: 404 });
}
