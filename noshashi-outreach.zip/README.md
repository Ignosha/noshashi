# NOSHASHI outreach engine

Institutional outreach and an AI reply agent for [noshashi.app](https://www.noshashi.app),
built to run at zero cost with no tier to outgrow and no trial to expire.

- **`worker.js`** — the whole system in one file. No build step, no npm, no dependencies.
- **`db/schema.sql`** — paste into the D1 console once.
- **`data/targets.json`** — seed institutions, with a fit hypothesis for each.
- **`docs/EVIDENCE.md`** — what you must be able to prove before you send. Read it first.
- **`docs/playbook.html`** — the email sequences, DM script, leave-behind and objection handling.

## Why it costs nothing

| Piece | What runs it | The real ceiling |
|---|---|---|
| Compute + cron | Workers free plan | 100,000 requests/day |
| Database | D1 free plan | 5 GB, 5M row reads/day |
| Pitch writing, triage, replies | Workers AI free allocation | daily neuron allowance |
| Inbound replies | Email Routing | unmetered |
| Outbound | SMTP through a mailbox you already own | your provider's cap (Gmail: 500/day) |

Nothing here is a trial and nothing expires. The honest caveat: Workers AI has a
daily free allowance, and if you exhaust it, generation stops until the next day.
At the sending pace this engine is tuned for — 60 emails/day, five per cron tick —
you will not come close. That pacing is also better outreach: personalised and
slow beats a blast into institutions that talk to each other.

## Setup

Everything below is done in a browser. You do not need Node installed.

**1. Create the database.** Cloudflare dashboard → Storage & Databases → D1 →
Create database, named `noshashi_outreach`. Open its Console, paste all of
`db/schema.sql`, run it.

**2. Create the Worker.** Compute → Workers & Pages → Create → Start from Hello
World. Name it `noshashi-outreach`. Click *Edit code*, select all, paste the whole
of `worker.js`, deploy.

**3. Bind resources.** Worker → Settings → Bindings:

| Type | Name | Value |
|---|---|---|
| D1 database | `DB` | `noshashi_outreach` |
| Workers AI | `AI` | — |

**4. Add variables** (Settings → Variables and Secrets). Plain text:

```
PUBLIC_BASE_URL    https://noshashi-outreach.<your-subdomain>.workers.dev
SENDING_DOMAIN     noshashi.app
OPERATOR_EMAIL     ignoshabuild@gmail.com
FORWARD_TO         ignoshabuild@gmail.com
FROM_NAME          Noshashi Labs
FROM_EMAIL         institutions@mail.noshashi.app
REPLY_TO           institutions@mail.noshashi.app
POSTAL_ADDRESS     <leave empty for now - see below>
SMTP_HOST          smtp.gmail.com
SMTP_PORT          587
SMTP_EHLO_DOMAIN   noshashi.app
```

Secrets (choose *Encrypt*):

```
SMTP_USER      ignoshabuild@gmail.com
SMTP_PASS      a Gmail App Password - NOT your account password
ADMIN_TOKEN    a long random string; guards the dashboard and every API route
UNSUB_SECRET   a different long random string; signs unsubscribe links
```

A Gmail App Password requires 2-Step Verification on the account, then
myaccount.google.com → Security → App passwords.

**`POSTAL_ADDRESS` is the one thing holding the send queue.** CAN-SPAM
(15 U.S.C. §7704(a)(5)) requires a real physical mailing address in every
commercial email, and there is no exemption for preferring not to publish one.
Until it is set, the queue stays held — but scoring, pitch generation, queueing,
the dashboard and the reply agent all work normally, so you can build and review
the entire pipeline first. When you are ready, a PO box or a virtual mailbox
service costs a few dollars a month and satisfies it without exposing where you
live. Set the variable and the queue drains on the next cron tick.

**Mail identity: `institutions@noshashi.app`.** Outreach is sent from it, replies
come back to it, and every reply is both handled by the agent and forwarded to
`ignoshabuild@gmail.com`. Sending from your personal Gmail address would get
filed as a scam by a bank's compliance desk before anyone read the first line;
sending from the domain is what makes the whole thing look like a company.

**Do these three steps in this order — the order matters.** Gmail verifies a
send-as alias by emailing a confirmation code to it. If the Worker route is
already live, the Worker swallows that code and you cannot complete verification:

1. **Route it to your inbox first.** Email → Email Routing → add
   `institutions@noshashi.app` with the action *Send to an email* →
   `ignoshabuild@gmail.com`. Verify that destination address when Cloudflare
   emails you.
2. **Verify the alias in Gmail.** Settings → Accounts → *Send mail as* → add
   `institutions@noshashi.app`, choose to send through Gmail's servers, and enter
   the confirmation code when it lands in your inbox. Gmail rejects any
   `MAIL FROM` that is neither the account nor a verified alias, so skipping this
   makes every send fail loudly at SMTP.
3. **Switch the route to the Worker.** Change that same rule's action to *Send to
   a Worker* → `noshashi-outreach`. The Worker forwards a copy to `FORWARD_TO`
   before it does anything else, so you keep seeing every reply in Gmail — a
   parsing bug in the agent can never be the reason an institution's reply
   disappears.

**Then fix DNS, or institutional filters will drop you.** Sending as
`@noshashi.app` through Google's servers needs these records on the domain
(Cloudflare → DNS → Records). Without SPF in particular, mail to a bank is
rejected outright rather than sent to spam:

| Type | Name | Value |
|---|---|---|
| TXT | `@` | `v=spf1 include:_spf.google.com ~all` |
| TXT | `google._domainkey` | the DKIM value Google generates for you |
| TXT | `_dmarc` | `v=DMARC1; p=none; rua=mailto:institutions@noshashi.app` |

DKIM is generated in Google Workspace admin (Apps → Google Workspace → Gmail →
Authenticate email). A free consumer Gmail account cannot produce a DKIM key for
your own domain — if you stay on consumer Gmail, SPF and DMARC still help, but
DKIM alignment will not pass. That is the practical reason to put the sending
mailbox on a paid Workspace account before approaching Tier 2 names. Start
`p=none` and only tighten to `quarantine` once you can see the reports.

**5. Set the cron.** Settings → Triggers → Cron Triggers → add `*/15 * * * *`.
Every tick drains up to five queued messages; the first tick of each hour also
queues follow-ups.

**6. Route inbound replies.** Covered by the three ordered steps above — get the
alias verified before you point `institutions@noshashi.app` at the Worker.

**7. Set `POSTAL_ADDRESS` when you are ready.** It is the only remaining thing
holding the send queue. Everything else runs without it.

## Using it

The dashboard is `https://<your-worker>/?k=<ADMIN_TOKEN>`. Every API route takes
the same token as `?k=` or a bearer header.

```bash
# 1. load the seed targets
curl -X POST "$BASE/api/institutions?k=$TOKEN" -H 'content-type: application/json' --data @data/targets.json

# 2. score fit - honest scores, including the reasons they would say no
curl -X POST "$BASE/api/score-all?k=$TOKEN&limit=10"

# 3. write and queue opening emails for the best-scoring targets
curl -X POST "$BASE/api/queue?k=$TOKEN&min_score=70&limit=5"

# 4. send now instead of waiting for the cron
curl -X POST "$BASE/api/drain?k=$TOKEN"
```

Add contacts yourself. `data/targets.json` deliberately ships without email
addresses — see the note at the top of that file for why.

## How the agent decides

A reply arrives → Email Routing hands it to the Worker → it is parsed, matched to
its thread, and classified. Then one of three things happens:

- **Unsubscribe** — suppressed immediately and permanently, queued messages
  cancelled, before anything else in the pipeline runs.
- **Simple** (FAQ, scheduling, wrong person, a clear no) with confidence ≥ 0.75 —
  the agent drafts and queues a reply from the FAQ only.
- **Everything else** — the thread is marked `needs_human`, you get an email, and
  it appears at the top of the dashboard.

Pricing negotiation, contracts, security reviews, DPAs, procurement, accessibility,
integration promises, delivery dates and any hostile message always escalate,
regardless of how confident the model is. That list is `ESCALATE_ALWAYS` in
`worker.js` — one array, easy to audit and easy to tighten.

## Compliance, built in rather than bolted on

- Physical postal address and a working opt-out in every message (CAN-SPAM
  15 U.S.C. §7704(a)(5))
- One-click `List-Unsubscribe` headers, and signed opt-out links that cannot be
  forged or used to enumerate contacts
- Opt-out honoured at domain scope, so one office can silence a whole institution
- A stated disclosure that correspondence is drafted by an automated assistant
  under human oversight
- Suppression re-checked at send time, not just at queue time
- An append-only `events` log — if a buyer ever asks what your AI told them, you
  can answer precisely

These are cheap now and expensive later. The people you are selling to are
professionally trained to notice when they are missing.
