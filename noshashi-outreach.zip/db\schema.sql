-- Noshashi institutional outreach engine
-- Cloudflare D1 (SQLite). Safe to re-run: every statement is IF NOT EXISTS.

CREATE TABLE IF NOT EXISTS institutions (
  id            TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  vertical      TEXT NOT NULL,          -- e.g. k12_district, university, hospital, food_bank
  segment       TEXT,                   -- free-text sub-segment used to pick a pitch angle
  country       TEXT NOT NULL DEFAULT 'US',
  region        TEXT,                   -- state / province
  website       TEXT,
  size_metric   TEXT,                   -- "48,000 students", "620 beds" - drives ROI math in the pitch
  size_value    INTEGER,                -- numeric form of size_metric, for sorting
  -- Fit analysis, written by the scoring pass (src/fit.ts)
  fit_score     INTEGER,                -- 0-100
  fit_reason    TEXT,                   -- why this institution specifically
  fit_risks     TEXT,                   -- what would make them say no
  -- Pipeline
  status        TEXT NOT NULL DEFAULT 'new'
                CHECK (status IN ('new','researched','queued','contacted','engaged','escalated','won','lost','suppressed')),
  -- Sales velocity at the product's current stage, not prestige.
  -- 1 reachable now  2 after references  3 needs SOC 2 / procurement  0 not a buyer
  -- Fed to the scorer, which caps what an unreachable institution can score.
  priority      INTEGER,
  notes         TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
-- Unique so re-importing the target list updates rows instead of duplicating
-- them. Without it, running the import twice silently doubles the pipeline.
CREATE UNIQUE INDEX IF NOT EXISTS idx_inst_name ON institutions(name);
CREATE INDEX IF NOT EXISTS idx_inst_status   ON institutions(status);
CREATE INDEX IF NOT EXISTS idx_inst_vertical ON institutions(vertical);
CREATE INDEX IF NOT EXISTS idx_inst_fit      ON institutions(fit_score DESC);

CREATE TABLE IF NOT EXISTS contacts (
  id             TEXT PRIMARY KEY,
  institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  name           TEXT,
  title          TEXT,
  email          TEXT NOT NULL,
  source         TEXT,                  -- where the address came from; keep this honest, it matters in a procurement review
  is_primary     INTEGER NOT NULL DEFAULT 0,
  created_at     TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (institution_id, email)
);
CREATE INDEX IF NOT EXISTS idx_contact_email ON contacts(email);

CREATE TABLE IF NOT EXISTS threads (
  id             TEXT PRIMARY KEY,
  institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  contact_id     TEXT NOT NULL REFERENCES contacts(id) ON DELETE CASCADE,
  subject        TEXT NOT NULL,
  state          TEXT NOT NULL DEFAULT 'open'
                 CHECK (state IN ('open','awaiting_reply','agent_handling','needs_human','closed_won','closed_lost','unsubscribed')),
  owner          TEXT NOT NULL DEFAULT 'agent' CHECK (owner IN ('agent','human')),
  escalation_reason TEXT,
  last_activity  TEXT NOT NULL DEFAULT (datetime('now')),
  created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_thread_state ON threads(state);
CREATE INDEX IF NOT EXISTS idx_thread_owner ON threads(owner, last_activity DESC);

CREATE TABLE IF NOT EXISTS messages (
  id            TEXT PRIMARY KEY,
  thread_id     TEXT NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
  direction     TEXT NOT NULL CHECK (direction IN ('outbound','inbound')),
  from_addr     TEXT NOT NULL,
  to_addr       TEXT NOT NULL,
  subject       TEXT NOT NULL,
  body          TEXT NOT NULL,
  -- RFC 5322 threading, so replies land in the same conversation in their mail client
  message_id    TEXT,
  in_reply_to   TEXT,
  status        TEXT NOT NULL DEFAULT 'queued'
                CHECK (status IN ('queued','held_for_review','sent','failed','bounced','received')),
  status_detail TEXT,
  authored_by   TEXT NOT NULL DEFAULT 'agent' CHECK (authored_by IN ('agent','human','contact')),
  send_after    TEXT,                   -- ISO timestamp; the cron drains anything due
  sent_at       TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_msg_thread ON messages(thread_id, created_at);
CREATE INDEX IF NOT EXISTS idx_msg_queue  ON messages(status, send_after);
CREATE INDEX IF NOT EXISTS idx_msg_msgid  ON messages(message_id);

-- CAN-SPAM: an opt-out must be honored for good, across every campaign.
-- Domain-level rows let one district office suppress the whole district.
CREATE TABLE IF NOT EXISTS suppressions (
  id         TEXT PRIMARY KEY,
  scope      TEXT NOT NULL CHECK (scope IN ('email','domain')),
  value      TEXT NOT NULL,
  reason     TEXT NOT NULL,             -- unsubscribe | bounce | complaint | manual
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (scope, value)
);

-- Append-only audit log. If a buyer ever asks "what did your AI tell us?", this is the answer.
CREATE TABLE IF NOT EXISTS events (
  id         TEXT PRIMARY KEY,
  thread_id  TEXT,
  kind       TEXT NOT NULL,
  payload    TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_events_thread ON events(thread_id, created_at DESC);
