# NOSHASHI outreach — runbook

Everything deployed. Worker at `noshashi-outreach.joshedmond18.workers.dev`,
D1 database `noshashi_outreach`, mail through Resend on `mail.noshashi.app`.

```powershell
$B = "https://noshashi-outreach.joshedmond18.workers.dev"
$T = "your admin token"
```

---

## Two things stand between you and it running unattended

**1. `POSTAL_ADDRESS` is unset.** The send queue is held until it is. CAN-SPAM
requires a real physical address in every commercial email; a PO box or virtual
mailbox (~$6/month) satisfies it. Set it in Worker → Settings → Variables, and
the queue drains on the next cron tick. Nothing else needs changing.

**2. You have three contacts.** All IR inboxes at the treasury companies. Every
other institution is scored and waiting with no one to write to. Add more with
`data/contacts.template.json` and `/api/contacts` — sourced honestly, never
scraped.

Until both are done, the system runs everything *except* sending.

---

## What runs by itself once those are set

| Every | What happens |
|---|---|
| 15 min | Drains up to 5 queued messages. Max 60/day. |
| 1 hour | Queues follow-ups: 6 days apart, 2 maximum, then the thread closes. |
| On reply | Forwarded to your Gmail, then triaged. |

On an inbound reply the agent answers FAQ, scheduling, wrong-person and clear-no
by itself, at confidence ≥ 0.75. **Everything else emails you and stops**:
pricing, contracts, security reviews, DPAs, procurement, accessibility,
integration or timeline commitments, and anything hostile. Unsubscribes are
honoured immediately and permanently, before anything else runs.

That escalation list is one array — `ESCALATE_ALWAYS` in `worker.js`. Widen it
freely; it is the cheapest safety you have.

---

## Daily use

```powershell
# What needs you
Invoke-RestMethod -Uri "$B/api/health?k=$T"

# Read the pitches before they go
$a = Invoke-RestMethod -Method Post -Uri "$B/api/audit?k=$T&limit=5"
$a.report | Format-List institution,verdict,problems,subject,body

# Queue one, by name
Invoke-RestMethod -Method Post -Uri "$B/api/queue?k=$T&name=Archax" | Format-List

# Send now instead of waiting for cron
Invoke-RestMethod -Method Post -Uri "$B/api/drain?k=$T"
```

Dashboard: `$B/?k=$T` — escalations at the top, best-fit table below.

---

## When something breaks

```powershell
Invoke-RestMethod -Uri "$B/api/diag?k=$T" | ConvertTo-Json -Depth 5
Invoke-RestMethod -Uri "$B/api/models?k=$T" | ConvertTo-Json -Depth 4
```

`diag` reports bindings, which secrets are set, the mail addresses, the build
marker and event counts. `models` probes each model id and says which work —
Cloudflare retires them, and `AI_MODEL` / `AI_MODEL_WRITE` override without a
redeploy.

Errors come back as JSON, not a bare 1101. The `events` table is the durable
trail:

```sql
SELECT created_at, kind, substr(payload,1,300) FROM events ORDER BY created_at DESC LIMIT 20;
```

---

## The rules that are enforced in code, not by hoping

- The queue will not drain while the product profile is incomplete.
- A pitch that cites a figure not in the evidence, repeats a withheld claim, or
  asks the recipient for their own data is **refused, not flagged**. It retries
  once, then declines to queue.
- The 913× claim is stripped from every prompt. The agent cannot cite it.
- One opening email per institution per 45 days.
- Suppression is re-checked at send time, not only at queue time.
- Every message carries a postal address, a working opt-out, one-click
  `List-Unsubscribe`, and a disclosure that it was drafted by an assistant.

---

## Do not let it run fully unattended on day one

Read the first ten pitches. The generator has produced fabricated figures and
asked a public company for its balance sheet, both caught by the gate. A gate
catches known failures, not new ones.

Start with three or four priority-1 institutions, read every word, and widen
once you have seen it behave.

---

## Still outstanding, outside this system

**The 913× figure is live on noshashi.app.** The fix is committed as
`0001-retire-913x.patch` but never pushed:

```bash
git am 0001-retire-913x.patch
git push origin main
```

Your site invites readers to re-measure findings. That one does not reproduce —
GateHub USD/XRP measured 1.1× on 2026-09-08. See `docs/EVIDENCE.md` §3.
