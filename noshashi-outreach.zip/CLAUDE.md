# Context for Claude

Handoff written 2026-09-08. Read this before touching anything.

---

## What this is

An institutional outreach engine for **NOSHASHI** (noshashi.app) — a desktop
tool doing pre-trade liquidity forensics and issuer compliance scoring on the
XRP Ledger. Product repo: `github.com/Ignosha/noshashi` (public, TypeScript +
Tauri). This repo is the *sales* system, not the product.

The engine scores institutions for fit, writes a per-institution opening email,
sends it, and triages the replies — answering simple ones and escalating
anything consequential to a human.

**Standing constraint from the user: completely free. No paid tiers, no trials.**
That applies to the tooling, not to NOSHASHI's own pricing ($749/seat,
$4,000/month).

---

## Environment — read this first, it cost hours

- **No Node, npm, npx, wrangler, or Python on this machine.** This is why
  `worker.js` is a single dependency-free file pasted into the Cloudflare
  dashboard editor. Do not propose a build step or a `launch.json` dev server;
  there is nothing to run one with.
- **Bash heredocs silently mangle backslashes.** Writing `'\\'` through
  `cat > file <<'EOF'` produced `'\'`, an unterminated string, and a Worker that
  would not deploy. **Write source files with the Write tool.** Heredocs are
  fine for prose and SQL.
- **No JS parser available.** Use `scratchpad/jslint.awk` (a small lexer written
  during this work) before handing over any `worker.js` edit. It handles nested
  template interpolation, regex literals, and `/` inside regex character
  classes. Character-counting checks do **not** catch unterminated strings and
  gave false confidence twice.
- **This network blocks `noshashi.app`** as a "newly-registered-domain". The
  in-app browser, curl and WebFetch all get the filter's 503. GitHub, Cloudflare,
  Resend and `xrplcluster.com` are all reachable.
- **The Claude in Chrome extension is not connected**, so there is no way to
  drive the user's authenticated browser sessions. All dashboard work is theirs.
- **Windows + PowerShell.** `curl` is an alias for `Invoke-WebRequest`; use
  `curl.exe` or `Invoke-RestMethod`. `@"` starts a here-string, so `--data @file`
  must be written `--data "@file"`. Git is installed but not on PATH:
  `C:\Users\JacksonvillePublic\AppData\Local\Programs\Git\cmd`.
- The user has repeatedly pasted placeholders literally (`TOKEN`,
  `PASTE_THE_ID`). Give commands that set a variable on its own line rather than
  burying a substitution mid-URL.

---

## Deployment state

| Thing | Value |
|---|---|
| Worker | `https://noshashi-outreach.joshedmond18.workers.dev` |
| D1 database | `noshashi_outreach` (bindings `DB`, `AI`) |
| Cron | `*/15 * * * *` |
| Mail domain | `mail.noshashi.app` (Resend, verified send + receive) |
| From / Reply-To | `institutions@mail.noshashi.app` |
| Forward + escalations | `ignoshabuild@gmail.com` |
| Inbound webhook | `POST /webhook/resend`, Svix-signed |
| Build marker | `two-models-1` (check via `/api/diag`) |

Secrets set in Worker settings: `RESEND_API_KEY`, `RESEND_WEBHOOK_SECRET`,
`ADMIN_TOKEN`, `UNSUB_SECRET`. **`POSTAL_ADDRESS` is deliberately unset** and
holds the send queue.

Everything is on free plans and **no payment method exists on any account**, so
overruns fail closed rather than billing.

---

## Architecture decisions and why

**Single-file Worker, no build.** Forced by the absent toolchain, and it turned
out to be the right call — the user deploys by pasting into the dashboard.

**Resend, not Cloudflare Email Routing.** Email Routing needs the domain on
Cloudflare DNS; `noshashi.app` is on Vercel DNS. Migrating nameservers on a live
site from a library PC was not worth the risk, and Resend already had working
SPF and DKIM on the domain. One additive MX record on a subdomain, zero risk to
the site.

**Two models.** `@cf/meta/llama-3.3-70b-instruct-fp8-fast` for writing (quality
is the product), `@cf/meta/llama-3.1-8b-instruct-fast` for scoring and triage
(short structured JSON, and 126 scoring calls on a 70B would drain the free
neuron allowance). Both overridable via `AI_MODEL_WRITE` / `AI_MODEL` — Cloudflare
retires model IDs, and one already bit us. `/api/models` probes what is live.

**Correctness is enforced, not requested.** Prompt instructions repeatedly
failed. What works is code:
- `productGaps()` blocks the queue while the profile is incomplete.
- `pitchProblems()` + `criticalProblems()` make `queuePitch` **refuse** to queue
  a pitch that cites a figure absent from the evidence, repeats a withheld
  claim, or asks the recipient for their own data. It retries once, then
  declines.
- Unsubstantiated proof points are **stripped from every prompt**, so the model
  cannot cite them even when asked.

**Never put concrete example sentences in a prompt.** The model copied them as
facts — including an example explicitly labelled as *wrong*. Describe properties
and banned words instead. This caused two rounds of fabrication.

---

## The 913x story — important

NOSHASHI's headline claim was that advertised XRPL depth overstates fillable
depth by **913x**, measured on GateHub USD/XRP, 2026-08-23.

**It does not reproduce.** Re-measured with the repo's own algorithm at ledger
106,850,183 on 2026-09-08: **1.1x**. The original reading caught a book that was
crossed and poisoned by one stale offer at 29x the market — a transient
condition, not a property of the pair.

This matters because the site invites readers to re-measure every finding it
publishes. A prospect who accepts that invitation gets 1.1x.

Replaced with a live six-pair sample at ledger 106,850,266: Bitstamp USD 1.0x,
GateHub USD 1.1x, GateHub EUR 1.9x, CNY 6.9x, **Sologenic SOLO 2,545x with 94.7%
of listed depth unfunded**, Bitstamp BTC 4,841x. **Median 4.4x.** The mechanism
is unfunded offers (`taker_gets_funded`), which is protocol-level and
independently checkable — a much stronger claim than the ratio alone.

The claim is marked `substantiated: false` in `PRODUCT.proofPoints` and withheld
from all prompts. `docs/EVIDENCE.md` §3 has the full record. The site fix is
committed as `0001-retire-913x.patch` and **has not been pushed**.

Any new depth figure must carry: ledger index, date, a control pair, and a
median alongside any maximum. Three disclosures travel with it — the 10% band is
a chosen parameter, AMM pools are excluded from the fill simulation, and
`book_offers` caps at 60 levels. All three bias the gap upward, in NOSHASHI's
favour.

---

## Targeting

`data/targets.json` — 126 institutions, each with a vertical, a `priority`
(sales velocity at beta stage, not prestige) and a fit hypothesis.

Six sellable verticals: `trading_desk`, `regulated_institution`, `token_issuer`,
`compliance_function`, `treasury_holder`, `payments_corridor`. Two that the
engine deliberately skips: `channel_partner` (Chainalysis, Refinitiv, Visa —
integration or distribution, not buyers) and `do_not_pitch` (four NGOs that
appear only because they received crypto donations).

`priority` is a hard cap in the scoring prompt: 0 disqualifies, 3 caps at 55,
2 caps at 75. Megabanks are priority 3 — genuinely unreachable at beta stage
without SOC 2 and references, and saying otherwise wastes the one introduction
available to each.

**The strongest finding of the analysis:** corporate XRP treasury companies
(Wellgistics, VivoPower, Hyperscale, Evernorth, Doppler) are the best near-term
market — a CFO with an auditor asking whether the mark is defensible, a hard
deadline, an existing budget line, and no incumbent vendor. Evernorth's
investors are Ripple, Arrington, SBI, Pantera, Kraken and GSR, all already on
the list, which makes it a warm-intro target rather than a cold one.

---

## Still open

1. **`POSTAL_ADDRESS`** — the only thing holding the send queue.
2. **Contacts** — three loaded, all IR inboxes. Never guess or scrape addresses;
   the user was told why and agreed.
3. **The 913x site fix** — patch exists, not pushed.
4. **This repo was never pushed.** `git init` done, one commit (`db0960c`),
   remote set to `Ignosha/noshashi-outreach`. Pushes fail because the user owns
   two GitHub accounts and the browser signs them in as `ignoshabuild-sudo`
   while the repo belongs to `Ignosha`. **Nothing is cached in git** — no
   Credential Manager entry, no GCM data dir — so clearing credentials does
   nothing. The fix is either signing out of GitHub in the browser, or
   `git config --global credential.gitHubAuthModes "basic"` and a personal
   access token entered at the terminal prompt. Never handle the token yourself.
5. **Pitch quality is unreviewed.** The user has not yet read a generated pitch
   they were happy with. The last one seen still used a banned subject and asked
   for a balance snapshot; the gate now blocks that, but the copy has not been
   re-checked since switching to the 70B model.

---

## Working style that fit this user

Short, concrete, one action at a time. They lose terminal variables between
sessions and lose the admin token regularly (it is write-only in Cloudflare —
regenerating and overwriting is the fix, and costs nothing).

They asked several times for work to be done *for* them — creating accounts,
setting dashboard variables, gathering contact emails, pushing to GitHub. Those
were declined for concrete reasons each time, not policy recitation: no
connected browser, credentials should not pass through the assistant, and
invented email addresses bounce and damage a newly authenticated sending domain.
Offering the nearest thing that *can* be done (a diagnostic endpoint, a public
IR lookup, a zip file) worked well.

Diagnostics added because a bare error cost several rounds each: JSON errors
instead of Cloudflare 1101, a build marker, `/api/diag`, `/api/models`, and an
append-only `events` table. Use them before guessing.
