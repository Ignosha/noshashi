# Evidence file

The engine will not let the AI make a claim that is not backed here. That is
deliberate. Everything below is what you need to be able to hand a skeptical head
of risk within one working day of them asking.

Sections 1 and 2 are complete: they rest on documented XRPL protocol behaviour
anyone can verify independently. Section 3 has been re-measured against live
mainnet, and the headline figure on your site does not survive it — read that
section before you quote any depth number.

---

## 1. Partial payments — COMPLETE, no measurement required

**Claim as used in outreach:** *"A payment's stated amount is a ceiling, not a
delivery. Systems that credit the stated figure rather than `delivered_amount`
credit the wrong number."*

**Status:** ✅ Fully substantiated. This is documented protocol behaviour, not a
finding of yours, which is exactly what makes it powerful — the recipient can
confirm it without trusting you at all.

**The evidence:**

- An XRPL `Payment` transaction with the `tfPartialPayment` flag (`0x00020000`)
  set may deliver less than the `Amount` field specifies. `Amount` becomes a
  maximum rather than an exact value.
- The authoritative delivered value is `delivered_amount` in the transaction
  metadata. XRPL's own documentation states directly that applications must use
  `delivered_amount` rather than `Amount` when crediting a payment.
- The failure mode is the "partial payment exploit": an exchange or processor
  that credits `Amount` can be induced to credit a large deposit against a
  near-zero delivery. Several exchanges were hit by this historically, which is
  precisely why the field exists in metadata.
- Every element of this is checkable against public ledger data and public
  protocol documentation. Cite the XRPL docs directly and let them verify.

**How to use it:** this is your door-opener for Tier 04 (compliance) and Tier 06
(payment corridors). It requires no trust in your methodology, costs the reader
ten minutes to confirm, and makes everything you say afterwards more credible.

**Do not overstate it:** the `$999,999 → $3,900` figure on your site is only
usable if it is a transaction you actually observed. If it is illustrative,
label it as illustrative. If it is real, record it here:

| Field | Your answer |
|---|---|
| Transaction hash | |
| Ledger index | |
| `Amount` field value | |
| `delivered_amount` value | |
| Observed, or constructed as an illustration? | |

---

## 2. Issuer permissions — COMPLETE, no measurement required

**Claims as used in outreach:** *"Issuers can freeze a trust line. XLS-77 deep
freeze can lock one entirely. Where clawback is enabled, an issuer can reclaim
tokens from a holder. None of this is visible to wallet-behaviour screening."*

**Status:** ✅ Substantiated by protocol design. These are ledger-level
capabilities with on-chain flags, readable by anyone.

**The evidence:**

- **Individual freeze** — an issuer can freeze a specific trust line, blocking
  that holder from sending the issued asset back into circulation.
- **Global freeze** — an account-level flag freezing all trust lines to that
  issuer at once.
- **Deep freeze (XLS-77)** — extends freeze so a holder can neither send *nor
  receive* the asset on that line, closing gaps the earlier freeze left open.
- **Clawback** — where `AllowTrustLineClawback` was enabled on the issuing
  account, the issuer can claw issued tokens back from a holder. Critically, it
  must be enabled *before* issuance, so it is a permanent property of the asset.
- **The screening blind spot is structural, not a vendor shortcoming.** Wallet
  analytics answer "is this counterparty risky". None of the above is counterparty
  behaviour — it is issuer configuration. A perfectly clean holder can be holding
  a clawback-enabled asset. Say it that way; it is accurate and it avoids
  attacking a tool the buyer already chose.

**One thing to verify before you send:** confirm which of these your product
reads *today* versus which are on the roadmap, and make `PRODUCT.capabilities` in
`worker.js` match exactly. The agent is forbidden from claiming anything outside
that list, so an inaccuracy there is the one way a false claim reaches a buyer.

---

## 3. The 913× claim — MEASURED, and it does not reproduce

**Status:** ⛔ Retired. Replaced by a live sample that is stronger. Read this
section before you use any depth figure anywhere.

### What the repo says

`src/lib/growth/posts.ts` records the finding as GateHub **USD/XRP**, dated
**2026-08-23**: advertised 12,692,991 USD, reachable 13,894 USD, factor 913×,
spread −18,675 bps before / 20 bps after.

**Good news first: the auto-bridging objection does not apply.** The pair has XRP
on one side, so there is nothing to bridge through. That concern is closed, and
your `uncrossedTouch()` already derives mid from the tightest uncrossed pair
rather than the poisoned touch — which is exactly the guard a quant would check
for second. That part of the code is sound.

### The re-measurement

Same pair, same algorithm, at **ledger 106,850,183 on 2026-09-08**:

| | Listed | Funded | Within 10% of mid | Ratio |
|---|---|---|---|---|
| GateHub USD/XRP | 248,521 | 248,340 | 234,690 | **1.1×** |

Not 913×. The book was not crossed, and there was no stale offer at the touch.
**The 913× reading caught a transient condition, not a property of the pair.**

**This is urgent because your own site invites verification.** `site/index.html`
tells the reader each tool "re-measures a finding we publish, so you never have to
take the number on trust." A prospect who takes you up on that gets 1.1× and
concludes the headline was marketing. That is a worse outcome than never
publishing the number.

### What to use instead — measured the same day, and stronger

Six XRPL pairs, same method, same ledger:

| Pair | Listed | Funded within band | Unfunded | Ratio |
|---|---|---|---|---|
| Bitstamp USD | 567,974 | 565,590 | 0.1% | 1.0× |
| GateHub USD | 248,521 | 234,690 | 0.1% | 1.1× |
| GateHub EUR | 249,570 | 130,588 | 0.0% | 1.9× |
| CNY (rKiCet) | 932,823 | 135,270 | 27.4% | 6.9× |
| Sologenic SOLO | 17,573,534 | 6,906 | **94.7%** | **2,545×** |
| Bitstamp BTC | 115 | 0 | **90.3%** | **4,841×** |

**Median 4.4×. Maximum 4,841×.**

This is a better story than 913× in every way that matters:

- **It reproduces.** Anyone can run it against a public node right now.
- **It has a median as well as a maximum**, which is what the playbook copy
  already promises to volunteer.
- **It explains the mechanism.** The gap is driven by *unfunded* offers — resting
  offers whose owner cannot cover them. `rippled` reports this in
  `taker_gets_funded`, and your `toLevels()` already handles it correctly. That
  is a protocol-level fact, not an opinion about a band width.
- **It says something useful.** Deep stablecoin books are close to honest;
  the danger is concentrated in long-tail assets. A desk hears that and believes
  you, because it matches what they already suspect.

The headline becomes: *"On XRPL, the depth you see and the depth you can fill are
the same number on Bitstamp USD and differ by 2,500× on SOLO. The difference is
offers nobody can honour."*

### Three disclosures to carry with any depth figure

All three bias the gap **upward, in your favour**, which is the direction that has
to be disclosed rather than discovered:

1. **The 10% band is a chosen parameter**, not a market fact. A wider band gives a
   smaller gap. Say which band you used.
2. **The exit simulation ignores AMM pools** — deliberately, and your code
   comments say so. Where a pool exists, the real exit is better than shown.
3. **`book_offers` is capped at 60 levels**, so both sides of the ratio are
   bounded by that limit.

### Action

- [ ] Replace the 913× figure on `site/index.html` and in `posts.ts` with the
      sample above, or re-date it explicitly as a one-off observation on a
      crossed book.
- [ ] Re-run the sample on the morning of any meeting. These are live books.
- [ ] Widen the sample beyond six pairs before quoting the median as a finding.

A quant will not argue with the number. They will ask one question, and if you
cannot answer it in thirty seconds you lose the meeting *and* the referral behind
it:

> "913× versus what, measured how, on which book, at what size?"

Unpinned, a ratio that large reads as marketing. Pinned to a specific ledger
state, it becomes the most compelling thing you own.

## 4. Claims that need tightening before use

**"Analytics run locally or client-side; data never hits a shared public server."**
A security claim, and a custodian's team will test it in a network tab. State
exactly what executes where, what leaves the browser, what you log, and what your
host can see. If any part runs server-side today, change the wording now — being
caught on this costs you every other claim on the page.

**"No other tool combines real liquidity depth with multi-layered compliance flags."**
An unprovable absolute. Narrow it to something defensible: name the tools you
checked and the date you checked them.

**Named companies.** Your brief and `data/targets.json` both mention firms such as
Ondo, Aviva and Guggenheim as examples of XRPL issuance. Never let a sentence
imply they are customers, users, or endorsers. "Issuers like X have brought assets
to XRPL" is fine. "Used by X" is not, unless it is contractually true.

**Product stage.** `PRODUCT.stage` is currently `'beta'`, inferred from your note
about free demo access. If the demo is a walkthrough rather than a buyer touching
live data, change it to `'prototype'`. The agent keys all of its honesty on this
field.

---

## 5. What Tier 02 and Tier 04 will ask for

Custodians, chartered banks and ETP issuers run vendor due diligence before a
first call becomes anything. Expect: SOC 2 Type II or a dated plan to obtain it;
a penetration test report or a booked date; a DPA and a data-residency statement;
business continuity and key-person risk; financials or evidence of runway; cyber
liability insurance; named references.

A beta-stage product clears none of that this quarter, and pretending otherwise
burns the one introduction you get to each firm.

**So sequence accordingly.** Trading desks, XRPL-native issuers, corporate XRP
treasuries and payment corridors can decide in weeks on one person's authority.
Custodians and chartered banks cannot. Win three of the former, convert them to
named references, and the latter become answerable rather than hopeless. The
`priority` field in `data/targets.json` already encodes this: 1 means approach
now, 3 means you are not ready for them yet.

---

## 6. Standing honesty rules

Enforced in code (`HONESTY` and `ESCALATE_ALWAYS` in `worker.js`), not merely
intended:

- Never claim a capability outside `PRODUCT.capabilities`
- Never invent customers, logos, metrics, certifications or case studies
- Never imply a maturity beyond `PRODUCT.stage`
- Never quote a price other than list price
- Never confirm a security posture, agree a deadline, or accept contract terms

The last three always escalate to you. Not caution for its own sake — those are
the answers that are expensive to get wrong in writing to a regulated
institution, and they are not the agent's to give.
