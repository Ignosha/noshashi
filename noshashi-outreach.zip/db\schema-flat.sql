CREATE TABLE IF NOT EXISTS institutions (
  id            TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  vertical      TEXT NOT NULL,
  segment       TEXT,
  country       TEXT NOT NULL DEFAULT 'US',
  region        TEXT,
  website       TEXT,
  size_metric   TEXT,
  size_value    INTEGER,
  fit_score     INTEGER,
  fit_reason    TEXT,
  fit_risks     TEXT,
  status        TEXT NOT NULL DEFAULT 'new'
                CHECK (status IN ('new','researched','queued','contacted','engaged','escalated','won','lost','suppressed')),
  priority      INTEGER,
  notes         TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_inst_name ON institutions(name);
CREATE INDEX IF NOT EXISTS idx_inst_status   ON institutions(status);
CREATE INDEX IF NOT EXISTS idx_inst_vertical ON institutions(vertical);
CREATE INDEX IF NOT EXISTS idx_inst_fit      ON institutions(fit_score DESC);
CREATE TABLE IF NOT EXISTS contacts (
  id             TEXT PRIMARY KEY,
  institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  name           TEXT,
  title          TEXT,
  email          TEXT NOT NULL,
  source         TEXT,
  is_primary     INTEGER NOT NULL DEFAULT 0,
  created_at     TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (institution_id, email)
);
CREATE INDEX IF NOT EXISTS idx_contact_email ON contacts(email);
CREATE TABLE IF NOT EXISTS threads (
  id             TEXT PRIMARY KEY,
  institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
  contact_id     TEXT NOT NULL REFERENCES contacts(id) ON DELETE CASCADE,
  subject        TEXT NOT NULL,
  state          TEXT NOT NULL DEFAULT 'open'
                 CHECK (state IN ('open','awaiting_reply','agent_handling','needs_human','closed_won','closed_lost','unsubscribed')),
  owner          TEXT NOT NULL DEFAULT 'agent' CHECK (owner IN ('agent','human')),
  escalation_reason TEXT,
  last_activity  TEXT NOT NULL DEFAULT (datetime('now')),
  created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_thread_state ON threads(state);
CREATE INDEX IF NOT EXISTS idx_thread_owner ON threads(owner, last_activity DESC);
CREATE TABLE IF NOT EXISTS messages (
  id            TEXT PRIMARY KEY,
  thread_id     TEXT NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
  direction     TEXT NOT NULL CHECK (direction IN ('outbound','inbound')),
  from_addr     TEXT NOT NULL,
  to_addr       TEXT NOT NULL,
  subject       TEXT NOT NULL,
  body          TEXT NOT NULL,
  message_id    TEXT,
  in_reply_to   TEXT,
  status        TEXT NOT NULL DEFAULT 'queued'
                CHECK (status IN ('queued','held_for_review','sent','failed','bounced','received')),
  status_detail TEXT,
  authored_by   TEXT NOT NULL DEFAULT 'agent' CHECK (authored_by IN ('agent','human','contact')),
  send_after    TEXT,
  sent_at       TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_msg_thread ON messages(thread_id, created_at);
CREATE INDEX IF NOT EXISTS idx_msg_queue  ON messages(status, send_after);
CREATE INDEX IF NOT EXISTS idx_msg_msgid  ON messages(message_id);
CREATE TABLE IF NOT EXISTS suppressions (
  id         TEXT PRIMARY KEY,
  scope      TEXT NOT NULL CHECK (scope IN ('email','domain')),
  value      TEXT NOT NULL,
  reason     TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (scope, value)
);
CREATE TABLE IF NOT EXISTS events (
  id         TEXT PRIMARY KEY,
  thread_id  TEXT,
  kind       TEXT NOT NULL,
  payload    TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_events_thread ON events(thread_id, created_at DESC);
