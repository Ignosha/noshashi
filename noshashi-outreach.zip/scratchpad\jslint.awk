# A small JS lexer. Not a parser - it exists to catch the one class of bug that
# character-counting structurally cannot: a string literal that never
# terminates, and brackets counted while inside strings, comments or regexes.
#
# Handles nested template interpolation (`a ${ `b` } c`) with a state stack,
# because that is legal JS and a naive scanner reports it as an error.

BEGIN { top = 0; stack[0] = "code"; st = "code"; dc = 0; dp = 0; db = 0; errs = 0 }

{
  line = $0
  n = length(line)
  for (i = 1; i <= n; i++) {
    c  = substr(line, i, 1)
    c2 = substr(line, i, 2)

    if (st == "code") {
      if (c2 == "//") break
      if (c2 == "/*") { st = "block"; i++; continue }
      if (c == "'")  { st = "sq"; continue }
      if (c == "\"") { st = "dq"; continue }
      if (c == "`")  { push("tmpl"); st = "tmpl"; continue }
      if (c == "/" && regex_ok(prev)) { st = "re"; cls = 0; continue }

      if (c == "{") dc++
      else if (c == "}") {
        # Closing an interpolation returns us to the enclosing template.
        if (top > 0 && stack[top] == "interp" && dc == entry[top]) {
          pop(); st = "tmpl"; prev = "}"; continue
        }
        dc--
      }
      else if (c == "(") dp++
      else if (c == ")") dp--
      else if (c == "[") db++
      else if (c == "]") db--

      if (c != " " && c != "\t") prev = c
      continue
    }

    if (st == "block") { if (c2 == "*/") { st = "code"; i++ }; continue }

    if (st == "tmpl") {
      if (c == "\\") { i++; continue }
      if (c2 == "${") { push("interp"); entry[top] = dc; st = "code"; prev = "{"; i++; continue }
      if (c == "`") { pop(); st = (top > 0 && stack[top] == "interp") ? "code" : "code"; prev = "`"; continue }
      continue
    }

    if (st == "sq" || st == "dq" || st == "re") {
      if (c == "\\") { i++; continue }
      if (st == "sq" && c == "'")  { st = "code"; prev = "'"; continue }
      if (st == "dq" && c == "\"") { st = "code"; prev = "\""; continue }
      if (st == "re") {
        # A "/" inside a character class does not end the regex: /([^/]+)/ is
        # legal JS, and treating it as a terminator miscounts everything after.
        if (c == "[") { cls = 1; continue }
        if (c == "]") { cls = 0; continue }
        if (c == "/" && !cls) { st = "code"; prev = "/"; continue }
      }
      continue
    }
  }

  # ' and " strings may not span lines in JS; template literals may.
  if (st == "sq" || st == "dq") {
    printf "UNTERMINATED %s STRING  line %d: %s\n", (st == "sq" ? "'" : "\""), NR, substr(line, 1, 110)
    errs++; st = "code"
  }
  if (st == "re") st = "code"
}

END {
  if (dc != 0) { printf "BRACE   imbalance outside literals: %+d\n", dc; errs++ }
  if (dp != 0) { printf "PAREN   imbalance outside literals: %+d\n", dp; errs++ }
  if (db != 0) { printf "BRACKET imbalance outside literals: %+d\n", db; errs++ }
  if (st == "tmpl" || top > 0) { printf "TEMPLATE literal never closed (depth %d)\n", top; errs++ }
  if (errs == 0) print "clean"
  exit (errs > 0)
}

function push(k) { top++; stack[top] = k }
function pop()   { if (top > 0) { delete stack[top]; top-- } }

function regex_ok(p) {
  if (p == "") return 1
  return (p == "(" || p == "," || p == "=" || p == ":" || p == "[" || p == "!" ||
          p == "&" || p == "|" || p == "?" || p == "{" || p == "}" || p == ";" ||
          p == "+" || p == "-" || p == "*" || p == "%" || p == "<" || p == ">" ||
          p == "~" || p == "^" || p == "return" )
}
