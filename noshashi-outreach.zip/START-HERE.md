# Start here

Picking this back up after a break. Last worked on 2026-09-08.

---

## Where things stand

The outreach engine is **built, deployed and running**. It scores institutions,
writes per-institution pitches, sends through Resend, and triages replies.

**It cannot send yet, on purpose.** One variable is missing and that holds the
whole outbound queue. Everything else runs.

| Piece | State |
|---|---|
| Cloudflare Worker | live at `noshashi-outreach.joshedmond18.workers.dev` |
| D1 database | 126 institutions, all scored |
| Workers AI | working — 70B for writing, 8B for scoring |
| Resend sending | verified on `mail.noshashi.app` |
| Resend inbound | verified end to end, replies forward to your Gmail |
| Send queue | **HELD** — `POSTAL_ADDRESS` not set |
| Contacts | only 3 (IR inboxes at the treasury companies) |

---

## To go live, in order

**1. Set `POSTAL_ADDRESS`.** Cloudflare → Worker → Settings → Variables. A PO box
or virtual mailbox (~$6/month) is fine; you do not need to publish a home
address. CAN-SPAM requires a real physical address in commercial email — this is
a legal gate, not a technical one. Once set, the queue drains on the next cron
tick with no other change.

**2. Add contacts.** You have three. The other 123 institutions are scored and
waiting with nobody to write to. Fill in `data/contacts.template.json` and POST
it to `/api/contacts`. Source addresses honestly — a firm's own site, a warm
intro, a conference list. Do not scrape; the buyers here are compliance officers
who will notice.

**3. Read the first ten pitches before sending any.** `/api/audit` generates and
checks them. The generator has previously invented a figure and asked a public
company for its balance sheet — both blocked by the gate, but a gate only
catches failures already known.

---

## Also outstanding, unrelated to the engine

**The 913x figure is still live on noshashi.app.** It does not reproduce — the
same pair measured 1.1x on 2026-09-08. Your own site invites readers to
re-measure published findings, so this is the one item with real downside. The
fix is committed as `0001-retire-913x.patch` but was never pushed:

```powershell
git clone https://github.com/Ignosha/noshashi.git
cd noshashi
git am ..\yuh\0001-retire-913x.patch
git push origin main
```

**This project was never pushed to GitHub either.** A repo exists at
`Ignosha/noshashi-outreach` but the push kept failing — see CLAUDE.md, the cause
is a two-account problem, not a git problem.

---

## Day-to-day commands

See `RUNBOOK.md`. Everything needs your admin token, which is stored only in
Cloudflare (write-only — if you lose it, generate a new one and overwrite the
variable; it takes 30 seconds and breaks nothing).

---

## If you want Claude to continue

Open this folder and say "read CLAUDE.md and continue". That file has the full
history, the architecture decisions and why they were made, the environment
quirks that cost time, and everything still open.
